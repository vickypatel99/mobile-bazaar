import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { MobileListing, ListingReport, UserProfile } from './src/types/index.ts';

const isProduction = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.resolve(DATA_DIR, 'uploads');
const DB_FILE = path.resolve(DATA_DIR, 'marketplace.json');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

interface DatabaseSchema {
  listings: MobileListing[];
  users: UserProfile[];
  reports: ListingReport[];
  favorites: Record<string, string[]>; // userPhone -> array of listingIds
}

// Initial realistic seed listings for MP
const INITIAL_LISTINGS: MobileListing[] = [
  {
    id: 'mp-list-101',
    brand: 'Apple iPhone',
    model: 'iPhone 13 (128 GB)',
    ram: '4 GB',
    storage: '128 GB',
    condition: 'like_new',
    purchaseYear: 2023,
    price: 36500,
    isNegotiable: true,
    description: 'Pristine condition iPhone 13. Battery health is at 91%. Zero dents or scratches, always used with Spigen case and matte tempered glass. Comes with original Apple packaging box and original USB-C Lightning braided cable. Bill available from Vijay Nagar Apple authorized store.',
    district: 'Indore',
    city: 'Vijay Nagar, Indore',
    photos: [
      '/src/assets/images/phone_iphone_showcase_1793892269375.jpg',
      '/src/assets/images/hero_smartphone_showcase_1793892269313.jpg'
    ],
    sellerName: 'Rahul Agrawal',
    sellerPhone: '9826012345',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '91%',
    status: 'active',
    viewsCount: 142,
    createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 18).toISOString(),
    isFeatured: true
  },
  {
    id: 'mp-list-102',
    brand: 'Samsung',
    model: 'Galaxy S24 Ultra 5G (256 GB)',
    ram: '12 GB',
    storage: '256 GB',
    condition: 'excellent',
    purchaseYear: 2024,
    price: 68000,
    isNegotiable: true,
    description: 'Selling my Galaxy S24 Ultra Titanium Black. Snapdragon 8 Gen 3, stunning 200MP camera, built-in S-Pen. 10 months warranty remaining. Original bill from Reliance Digital DB Mall Bhopal. Box and charging cable included.',
    district: 'Bhopal',
    city: 'MP Nagar Zone 2, Bhopal',
    photos: [
      '/src/assets/images/phone_samsung_showcase_1793892269425.jpg',
      '/src/assets/images/hero_smartphone_showcase_1793892269313.jpg'
    ],
    sellerName: 'Anand Sharma',
    sellerPhone: '9425098765',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '100%',
    status: 'active',
    viewsCount: 204,
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    isFeatured: true
  },
  {
    id: 'mp-list-103',
    brand: 'OnePlus',
    model: 'OnePlus 11R 5G (128 GB)',
    ram: '8 GB',
    storage: '128 GB',
    condition: 'excellent',
    purchaseYear: 2023,
    price: 21500,
    isNegotiable: true,
    description: 'Emerald Green OnePlus 11R. Super fast 100W SuperVOOC charger fills 100% in 25 mins. Snapdragon 8+ Gen 1 processor. Flawless curved AMOLED display. Hand-to-hand deal preferred in Ujjain Freeganj area.',
    district: 'Ujjain',
    city: 'Freeganj, Madhav Club Road, Ujjain',
    photos: [
      '/src/assets/images/phone_oneplus_showcase_1793892268583.jpg'
    ],
    sellerName: 'Vikas Malviya',
    sellerPhone: '9893054321',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '93%',
    status: 'active',
    viewsCount: 88,
    createdAt: new Date(Date.now() - 3600000 * 28).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 28).toISOString(),
    isFeatured: false
  },
  {
    id: 'mp-list-104',
    brand: 'Xiaomi / Redmi',
    model: 'Redmi Note 13 Pro+ 5G (256 GB)',
    ram: '12 GB',
    storage: '256 GB',
    condition: 'like_new',
    purchaseYear: 2024,
    price: 18900,
    isNegotiable: false,
    description: 'Fusion Purple colour, 200MP camera with OIS, 120W HyperCharge (19 min full charge). IP68 water resistance. Just 4 months old, selling to upgrade. Bill, original box and 120W adapter provided.',
    district: 'Jabalpur',
    city: 'Civil Lines, Jabalpur',
    photos: [
      '/src/assets/images/hero_smartphone_showcase_1793892269313.jpg'
    ],
    sellerName: 'Pooja Tiwari',
    sellerPhone: '9752011223',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '97%',
    status: 'active',
    viewsCount: 115,
    createdAt: new Date(Date.now() - 3600000 * 40).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 40).toISOString(),
    isFeatured: false
  },
  {
    id: 'mp-list-105',
    brand: 'Vivo',
    model: 'Vivo V29 5G (128 GB)',
    ram: '8 GB',
    storage: '128 GB',
    condition: 'excellent',
    purchaseYear: 2023,
    price: 17200,
    isNegotiable: true,
    description: 'Himalayan Blue with Smart Aura Light portrait camera. Best camera phone in this price range. Very light and slim design. All sensors and fingerprint working smoothly.',
    district: 'Gwalior',
    city: 'City Centre, Gwalior',
    photos: [
      '/src/assets/images/phone_samsung_showcase_1793892269425.jpg'
    ],
    sellerName: 'Deepak Sikarwar',
    sellerPhone: '9406588990',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '90%',
    status: 'active',
    viewsCount: 76,
    createdAt: new Date(Date.now() - 3600000 * 52).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 52).toISOString(),
    isFeatured: false
  },
  {
    id: 'mp-list-106',
    brand: 'Realme',
    model: 'Realme 12 Pro 5G (128 GB)',
    ram: '8 GB',
    storage: '128 GB',
    condition: 'like_new',
    purchaseYear: 2024,
    price: 14500,
    isNegotiable: true,
    description: 'Submarine Blue luxury watch design back. 32MP Sony Telephoto portrait lens with 2X zoom. 67W fast charging. Used very carefully with back film. Original box and bill available.',
    district: 'Ratlam',
    city: 'Station Road, Ratlam',
    photos: [
      '/src/assets/images/phone_oneplus_showcase_1793892268583.jpg'
    ],
    sellerName: 'Jitendra Rathore',
    sellerPhone: '9827033445',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '96%',
    status: 'active',
    viewsCount: 95,
    createdAt: new Date(Date.now() - 3600000 * 64).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 64).toISOString(),
    isFeatured: false
  },
  {
    id: 'mp-list-107',
    brand: 'Motorola',
    model: 'Moto Edge 40 (256 GB)',
    ram: '8 GB',
    storage: '256 GB',
    condition: 'good',
    purchaseYear: 2023,
    price: 13800,
    isNegotiable: true,
    description: 'Eclipse Black vegan leather finish. Clean stock Android with no ads or bloatware. 144Hz 3D curved pOLED screen. Very minor paint wear near charging port, otherwise 100% fine.',
    district: 'Sagar',
    city: 'Civil Lines, Sagar',
    photos: [
      '/src/assets/images/hero_smartphone_showcase_1793892269313.jpg'
    ],
    sellerName: 'Manish Ahirwar',
    sellerPhone: '9926077889',
    whatsappEnabled: true,
    includesBill: false,
    includesBox: true,
    includesCharger: true,
    batteryHealth: '88%',
    status: 'active',
    viewsCount: 63,
    createdAt: new Date(Date.now() - 3600000 * 75).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 75).toISOString(),
    isFeatured: false
  },
  {
    id: 'mp-list-108',
    brand: 'Nothing',
    model: 'Nothing Phone (2) (256 GB)',
    ram: '12 GB',
    storage: '256 GB',
    condition: 'like_new',
    purchaseYear: 2024,
    price: 25900,
    isNegotiable: true,
    description: 'Dark Grey Glyph interface phone. Snapdragon 8+ Gen 1 flagship chip. Clean Nothing OS 2.6. Glyph LEDs all working flawlessly. In warranty till Nov 2024. Deal in Rewa.',
    district: 'Rewa',
    city: 'College Road, Rewa',
    photos: [
      '/src/assets/images/phone_iphone_showcase_1793892269375.jpg'
    ],
    sellerName: 'Prateek Mishra',
    sellerPhone: '9425166778',
    whatsappEnabled: true,
    includesBill: true,
    includesBox: true,
    includesCharger: false,
    batteryHealth: '94%',
    status: 'active',
    viewsCount: 130,
    createdAt: new Date(Date.now() - 3600000 * 90).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 90).toISOString(),
    isFeatured: false
  }
];

const INITIAL_USERS: UserProfile[] = [
  {
    phone: '9826012345',
    name: 'Rahul Agrawal',
    district: 'Indore',
    city: 'Vijay Nagar, Indore',
    registeredAt: new Date(Date.now() - 3600000 * 200).toISOString(),
    role: 'admin'
  },
  {
    phone: '9425098765',
    name: 'Anand Sharma',
    district: 'Bhopal',
    city: 'MP Nagar, Bhopal',
    registeredAt: new Date(Date.now() - 3600000 * 180).toISOString(),
    role: 'user'
  }
];

function loadDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading db file, restoring defaults:', err);
  }
  const defaultDb: DatabaseSchema = {
    listings: INITIAL_LISTINGS,
    users: INITIAL_USERS,
    reports: [],
    favorites: {
      '9826012345': ['mp-list-102']
    }
  };
  saveDatabase(defaultDb);
  return defaultDb;
}

function saveDatabase(db: DatabaseSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving db:', err);
  }
}

// Helper to save base64 photo to disk and return public path
function savePhotoToDisk(photoDataUrl: string): string {
  if (!photoDataUrl.startsWith('data:image')) {
    return photoDataUrl; // Already a URL or path
  }
  try {
    const matches = photoDataUrl.match(/^data:image\/([a-zA-Z0-9]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return photoDataUrl;
    }
    const extension = matches[1] === 'jpeg' ? 'jpg' : matches[1];
    const base64Data = matches[2];
    const filename = `phone_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${extension}`;
    const filePath = path.join(UPLOADS_DIR, filename);
    fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
    return `/uploads/${filename}`;
  } catch (err) {
    console.error('Error saving base64 photo to disk:', err);
    return photoDataUrl;
  }
}

async function startServer() {
  const app = express();
  let db = loadDatabase();

  app.use(express.json({ limit: '60mb' }));
  app.use(express.urlencoded({ extended: true, limit: '60mb' }));

  // Serve persistent uploads
  app.use('/uploads', express.static(UPLOADS_DIR));

  // --- API Routes ---

  // Get listings with filters
  app.get('/api/listings', (req: Request, res: Response) => {
    db = loadDatabase();
    let result = [...db.listings].filter(l => l.status !== 'inactive');

    const { q, brand, district, minPrice, maxPrice, condition, ram, storage, sort, sellerPhone } = req.query;

    if (sellerPhone) {
      result = db.listings.filter(l => l.sellerPhone === String(sellerPhone));
      return res.json({ success: true, listings: result, count: result.length });
    }

    if (q) {
      const term = String(q).toLowerCase().trim();
      result = result.filter(item => 
        item.brand.toLowerCase().includes(term) ||
        item.model.toLowerCase().includes(term) ||
        item.description.toLowerCase().includes(term) ||
        item.district.toLowerCase().includes(term) ||
        item.city.toLowerCase().includes(term)
      );
    }

    if (brand && brand !== 'all') {
      result = result.filter(item => item.brand.toLowerCase() === String(brand).toLowerCase());
    }

    if (district && district !== 'all') {
      result = result.filter(item => item.district.toLowerCase() === String(district).toLowerCase());
    }

    if (condition && condition !== 'all') {
      result = result.filter(item => item.condition === String(condition));
    }

    if (ram && ram !== 'all') {
      result = result.filter(item => item.ram.replace(/\s+/g, '') === String(ram).replace(/\s+/g, ''));
    }

    if (storage && storage !== 'all') {
      result = result.filter(item => item.storage.replace(/\s+/g, '') === String(storage).replace(/\s+/g, ''));
    }

    if (minPrice) {
      const min = Number(minPrice);
      if (!isNaN(min)) {
        result = result.filter(item => item.price >= min);
      }
    }

    if (maxPrice) {
      const max = Number(maxPrice);
      if (!isNaN(max)) {
        result = result.filter(item => item.price <= max);
      }
    }

    // Sorting
    if (sort === 'price_asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sort === 'price_desc') {
      result.sort((a, b) => b.price - a.price);
    } else {
      // Default: newest first
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    res.json({
      success: true,
      listings: result,
      count: result.length
    });
  });

  // Get single listing & increment view
  app.get('/api/listings/:id', (req: Request, res: Response) => {
    db = loadDatabase();
    const listing = db.listings.find(l => l.id === req.params.id);
    if (!listing) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    listing.viewsCount = (listing.viewsCount || 0) + 1;
    saveDatabase(db);

    res.json({ success: true, listing });
  });

  // Create listing
  app.post('/api/listings', (req: Request, res: Response) => {
    const payload = req.body;
    if (!payload.brand || !payload.model || !payload.price || !payload.district || !payload.sellerPhone) {
      return res.status(400).json({ success: false, message: 'Missing required mobile details' });
    }

    // Process uploaded photos (up to 8)
    const rawPhotos: string[] = Array.isArray(payload.photos) ? payload.photos.slice(0, 8) : [];
    const savedPhotos = rawPhotos.map(p => savePhotoToDisk(p));

    const newListing: MobileListing = {
      id: `mp-phone-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      brand: String(payload.brand).trim(),
      model: String(payload.model).trim(),
      ram: payload.ram || '8 GB',
      storage: payload.storage || '128 GB',
      condition: payload.condition || 'good',
      purchaseYear: Number(payload.purchaseYear) || new Date().getFullYear(),
      price: Number(payload.price) || 0,
      isNegotiable: Boolean(payload.isNegotiable),
      description: String(payload.description || '').trim(),
      district: String(payload.district).trim(),
      city: String(payload.city || '').trim(),
      photos: savedPhotos.length > 0 ? savedPhotos : ['/src/assets/images/hero_smartphone_showcase_1793892269313.jpg'],
      sellerName: String(payload.sellerName || 'Seller').trim(),
      sellerPhone: String(payload.sellerPhone).trim(),
      whatsappEnabled: payload.whatsappEnabled !== false,
      includesBill: Boolean(payload.includesBill),
      includesBox: Boolean(payload.includesBox),
      includesCharger: Boolean(payload.includesCharger),
      batteryHealth: payload.batteryHealth ? String(payload.batteryHealth) : undefined,
      status: 'active',
      viewsCount: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isFeatured: false
    };

    db = loadDatabase();
    db.listings.unshift(newListing);

    // Ensure user exists
    let user = db.users.find(u => u.phone === newListing.sellerPhone);
    if (!user) {
      user = {
        phone: newListing.sellerPhone,
        name: newListing.sellerName,
        district: newListing.district,
        city: newListing.city,
        registeredAt: new Date().toISOString(),
        role: newListing.sellerPhone === '9826012345' ? 'admin' : 'user'
      };
      db.users.push(user);
    }

    saveDatabase(db);
    res.json({ success: true, listing: newListing });
  });

  // Update listing
  app.put('/api/listings/:id', (req: Request, res: Response) => {
    db = loadDatabase();
    const index = db.listings.findIndex(l => l.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    const current = db.listings[index];
    const payload = req.body;

    let updatedPhotos = current.photos;
    if (Array.isArray(payload.photos)) {
      updatedPhotos = payload.photos.slice(0, 8).map((p: string) => savePhotoToDisk(p));
    }

    const updatedListing: MobileListing = {
      ...current,
      ...payload,
      photos: updatedPhotos,
      price: payload.price !== undefined ? Number(payload.price) : current.price,
      updatedAt: new Date().toISOString()
    };

    db.listings[index] = updatedListing;
    saveDatabase(db);

    res.json({ success: true, listing: updatedListing });
  });

  // Delete listing
  app.delete('/api/listings/:id', (req: Request, res: Response) => {
    db = loadDatabase();
    const initialLen = db.listings.length;
    db.listings = db.listings.filter(l => l.id !== req.params.id);

    if (db.listings.length === initialLen) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    saveDatabase(db);
    res.json({ success: true, message: 'Listing deleted successfully' });
  });

  // Toggle favorite
  app.post('/api/listings/:id/favorite', (req: Request, res: Response) => {
    const { userPhone } = req.body;
    if (!userPhone) {
      return res.status(400).json({ success: false, message: 'User phone required' });
    }

    db = loadDatabase();
    if (!db.favorites) db.favorites = {};
    if (!db.favorites[userPhone]) db.favorites[userPhone] = [];

    const listId = req.params.id;
    const isFav = db.favorites[userPhone].includes(listId);

    if (isFav) {
      db.favorites[userPhone] = db.favorites[userPhone].filter(id => id !== listId);
    } else {
      db.favorites[userPhone].push(listId);
    }

    saveDatabase(db);
    res.json({ success: true, isFavorite: !isFav, favorites: db.favorites[userPhone] });
  });

  // Get user favorites
  app.get('/api/favorites/:userPhone', (req: Request, res: Response) => {
    db = loadDatabase();
    const favIds = (db.favorites && db.favorites[req.params.userPhone]) || [];
    const favListings = db.listings.filter(l => favIds.includes(l.id));
    res.json({ success: true, favorites: favIds, listings: favListings });
  });

  // Report suspicious listing
  app.post('/api/listings/:id/report', (req: Request, res: Response) => {
    const { reporterPhone, reason, details } = req.body;
    db = loadDatabase();
    const listing = db.listings.find(l => l.id === req.params.id);

    if (!listing) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    const newReport: ListingReport = {
      id: `rep-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      listingId: listing.id,
      listingTitle: `${listing.brand} ${listing.model}`,
      reporterPhone: String(reporterPhone || 'Anonymous').trim(),
      reason: String(reason || 'Suspicious listing').trim(),
      details: String(details || '').trim(),
      createdAt: new Date().toISOString(),
      status: 'pending'
    };

    if (!db.reports) db.reports = [];
    db.reports.unshift(newReport);
    saveDatabase(db);

    res.json({ success: true, report: newReport });
  });

  // Auth: Login / Register with mobile OTP
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { phone, name, district, city, otp } = req.body;
    const cleanPhone = String(phone || '').replace(/\D/g, '').slice(-10);

    if (cleanPhone.length !== 10) {
      return res.status(400).json({ success: false, message: 'Invalid 10-digit mobile number' });
    }

    // OTP verification: allows demo PIN '1234' or any 4 digit numeric PIN for frictionless authentication
    if (otp && !/^\d{4}$/.test(otp)) {
      return res.status(400).json({ success: false, message: 'OTP must be 4 digits' });
    }

    db = loadDatabase();
    let user = db.users.find(u => u.phone === cleanPhone);

    const isAdmin = cleanPhone === '9826012345';

    if (!user) {
      user = {
        phone: cleanPhone,
        name: name || `MP User ${cleanPhone.slice(-4)}`,
        district: district || 'Indore',
        city: city || 'Indore',
        registeredAt: new Date().toISOString(),
        role: isAdmin ? 'admin' : 'user'
      };
      db.users.push(user);
    } else {
      if (name) user.name = name;
      if (district) user.district = district;
      if (city) user.city = city;
      if (isAdmin) user.role = 'admin';
    }

    saveDatabase(db);
    res.json({
      success: true,
      user,
      token: `mb-tok-${cleanPhone}-${Date.now()}`
    });
  });

  // Get user profile
  app.get('/api/auth/user/:phone', (req: Request, res: Response) => {
    db = loadDatabase();
    const user = db.users.find(u => u.phone === req.params.phone);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({ success: true, user });
  });

  // Admin: Get all reports
  app.get('/api/admin/reports', (req: Request, res: Response) => {
    db = loadDatabase();
    res.json({ success: true, reports: db.reports || [] });
  });

  // Admin: Action on report
  app.post('/api/admin/reports/:id/action', (req: Request, res: Response) => {
    const { action } = req.body; // 'dismiss' | 'delete_listing' | 'resolve'
    db = loadDatabase();
    const reportIndex = (db.reports || []).findIndex(r => r.id === req.params.id);

    if (reportIndex === -1) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }

    const report = db.reports[reportIndex];

    if (action === 'delete_listing') {
      db.listings = db.listings.filter(l => l.id !== report.listingId);
      report.status = 'resolved';
    } else if (action === 'dismiss') {
      report.status = 'dismissed';
    } else {
      report.status = 'resolved';
    }

    saveDatabase(db);
    res.json({ success: true, report });
  });

  // Admin: Stats overview
  app.get('/api/admin/stats', (req: Request, res: Response) => {
    db = loadDatabase();
    const total = db.listings.length;
    const active = db.listings.filter(l => l.status === 'active').length;
    const sold = db.listings.filter(l => l.status === 'sold').length;
    const reported = (db.reports || []).filter(r => r.status === 'pending').length;
    const users = db.users.length;

    res.json({
      success: true,
      stats: { total, active, sold, reported, users }
    });
  });

  // Admin: Get all users
  app.get('/api/admin/users', (req: Request, res: Response) => {
    db = loadDatabase();
    res.json({ success: true, users: db.users });
  });

  // Admin: Toggle ban user
  app.post('/api/admin/users/:phone/ban', (req: Request, res: Response) => {
    db = loadDatabase();
    const user = db.users.find(u => u.phone === req.params.phone);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    user.isBanned = !user.isBanned;
    saveDatabase(db);
    res.json({ success: true, user });
  });

  // Vite Integration
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Mobile Bazaar] Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start Mobile Bazaar server:', err);
  process.exit(1);
});
