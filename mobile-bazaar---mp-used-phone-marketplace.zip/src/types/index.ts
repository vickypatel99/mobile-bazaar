export type PhoneCondition = 'like_new' | 'excellent' | 'good' | 'fair';

export interface MobileListing {
  id: string;
  brand: string;
  model: string;
  ram: string;
  storage: string;
  condition: PhoneCondition;
  purchaseYear: number;
  price: number;
  isNegotiable: boolean;
  description: string;
  district: string;
  city: string;
  photos: string[];
  sellerName: string;
  sellerPhone: string;
  whatsappEnabled: boolean;
  includesBill: boolean;
  includesBox: boolean;
  includesCharger: boolean;
  batteryHealth?: string;
  status: 'active' | 'sold' | 'inactive';
  viewsCount: number;
  createdAt: string;
  updatedAt: string;
  isFeatured?: boolean;
}

export interface UserProfile {
  phone: string;
  name: string;
  district: string;
  city: string;
  registeredAt: string;
  role: 'user' | 'admin';
  isBanned?: boolean;
}

export interface ListingReport {
  id: string;
  listingId: string;
  listingTitle: string;
  reporterPhone: string;
  reason: string;
  details: string;
  createdAt: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

export interface MPDistrict {
  id: string;
  en: string;
  hi: string;
  zone?: string;
}

export const MP_DISTRICTS: MPDistrict[] = [
  { id: 'indore', en: 'Indore', hi: 'इंदौर', zone: 'Malwa' },
  { id: 'bhopal', en: 'Bhopal', hi: 'भोपाल', zone: 'Bhopal' },
  { id: 'ujjain', en: 'Ujjain', hi: 'उज्जैन', zone: 'Malwa' },
  { id: 'jabalpur', en: 'Jabalpur', hi: 'जबलपुर', zone: 'Mahakoshal' },
  { id: 'gwalior', en: 'Gwalior', hi: 'ग्वालियर', zone: 'Chambal' },
  { id: 'sagar', en: 'Sagar', hi: 'सागर', zone: 'Bundelkhand' },
  { id: 'rewa', en: 'Rewa', hi: 'रीवा', zone: 'Baghelkhand' },
  { id: 'satna', en: 'Satna', hi: 'सतना', zone: 'Baghelkhand' },
  { id: 'ratlam', en: 'Ratlam', hi: 'रतलाम', zone: 'Malwa' },
  { id: 'dewas', en: 'Dewas', hi: 'देवास', zone: 'Malwa' },
  { id: 'chhindwara', en: 'Chhindwara', hi: 'छिंदवाड़ा', zone: 'Mahakoshal' },
  { id: 'dhar', en: 'Dhar', hi: 'धार', zone: 'Malwa' },
  { id: 'khandwa', en: 'Khandwa (East Nimar)', hi: 'खंडवा (पूर्वी निमाड़)', zone: 'Nimar' },
  { id: 'khargone', en: 'Khargone (West Nimar)', hi: 'खरगोन (पश्चिमी निमाड़)', zone: 'Nimar' },
  { id: 'sehore', en: 'Sehore', hi: 'सीहोर', zone: 'Bhopal' },
  { id: 'vidisha', en: 'Vidisha', hi: 'विदिशा', zone: 'Bhopal' },
  { id: 'mandsaur', en: 'Mandsaur', hi: 'मंदसौर', zone: 'Malwa' },
  { id: 'neemuch', en: 'Neemuch', hi: 'नीमच', zone: 'Malwa' },
  { id: 'shivpuri', en: 'Shivpuri', hi: 'शिवपुरी', zone: 'Gwalior' },
  { id: 'morena', en: 'Morena', hi: 'मुरैना', zone: 'Chambal' },
  { id: 'bhind', en: 'Bhind', hi: 'भिंड', zone: 'Chambal' },
  { id: 'narmadapuram', en: 'Narmadapuram (Hoshangabad)', hi: 'नर्मदापुरम (होशंगाबाद)', zone: 'Narmadapuram' },
  { id: 'harda', en: 'Harda', hi: 'हरदा', zone: 'Narmadapuram' },
  { id: 'betul', en: 'Betul', hi: 'बैतूल', zone: 'Narmadapuram' },
  { id: 'balaghat', en: 'Balaghat', hi: 'बालाघाट', zone: 'Mahakoshal' },
  { id: 'seoni', en: 'Seoni', hi: 'सिवनी', zone: 'Mahakoshal' },
  { id: 'damoh', en: 'Damoh', hi: 'दमोह', zone: 'Bundelkhand' },
  { id: 'panna', en: 'Panna', hi: 'पन्ना', zone: 'Bundelkhand' },
  { id: 'chhatarpur', en: 'Chhatarpur', hi: 'छतरपुर', zone: 'Bundelkhand' },
  { id: 'tikamgarh', en: 'Tikamgarh', hi: 'टीकमगढ़', zone: 'Bundelkhand' },
  { id: 'niwari', en: 'Niwari', hi: 'निवाड़ी', zone: 'Bundelkhand' },
  { id: 'singrauli', en: 'Singrauli', hi: 'सिंगरौली', zone: 'Baghelkhand' },
  { id: 'sidhi', en: 'Sidhi', hi: 'सीधी', zone: 'Baghelkhand' },
  { id: 'shahdol', en: 'Shahdol', hi: 'शहडोल', zone: 'Shahdol' },
  { id: 'anuppur', en: 'Anuppur', hi: 'अनूपपुर', zone: 'Shahdol' },
  { id: 'umaria', en: 'Umaria', hi: 'उमरिया', zone: 'Shahdol' },
  { id: 'dindori', en: 'Dindori', hi: 'डिंडोरी', zone: 'Mahakoshal' },
  { id: 'mandla', en: 'Mandla', hi: 'मंडला', zone: 'Mahakoshal' },
  { id: 'katni', en: 'Katni', hi: 'कटनी', zone: 'Mahakoshal' },
  { id: 'raisen', en: 'Raisen', hi: 'रायसेन', zone: 'Bhopal' },
  { id: 'rajgarh', en: 'Rajgarh', hi: 'राजगढ़', zone: 'Bhopal' },
  { id: 'shajapur', en: 'Shajapur', hi: 'शाजापुर', zone: 'Malwa' },
  { id: 'agar_malwa', en: 'Agar Malwa', hi: 'आगर मालवा', zone: 'Malwa' },
  { id: 'alirajpur', en: 'Alirajpur', hi: 'अलीराजपुर', zone: 'Malwa' },
  { id: 'jhabua', en: 'Jhabua', hi: 'झाबुआ', zone: 'Malwa' },
  { id: 'barwani', en: 'Barwani', hi: 'बड़वानी', zone: 'Nimar' },
  { id: 'burhanpur', en: 'Burhanpur', hi: 'बुरहानपुर', zone: 'Nimar' },
  { id: 'ashoknagar', en: 'Ashoknagar', hi: 'अशोकनगर', zone: 'Gwalior' },
  { id: 'guna', en: 'Guna', hi: 'गुना', zone: 'Gwalior' },
  { id: 'datia', en: 'Datia', hi: 'दतिया', zone: 'Gwalior' },
  { id: 'sheopur', en: 'Sheopur', hi: 'श्योपुर', zone: 'Chambal' },
  { id: 'narsinghpur', en: 'Narsinghpur', hi: 'नरसिंहपुर', zone: 'Mahakoshal' },
  { id: 'maihar', en: 'Maihar', hi: 'मैहर', zone: 'Baghelkhand' },
  { id: 'mauganj', en: 'Mauganj', hi: 'मऊगंज', zone: 'Baghelkhand' },
  { id: 'pandhurna', en: 'Pandhurna', hi: 'पांढुरना', zone: 'Mahakoshal' }
];

export const POPULAR_BRANDS = [
  'Apple iPhone',
  'Samsung',
  'OnePlus',
  'Xiaomi / Redmi',
  'Vivo',
  'Realme',
  'Oppo',
  'Motorola',
  'Google Pixel',
  'Nothing',
  'POCO',
  'iQOO',
  'Infinix'
];

export const RAM_OPTIONS = ['3 GB', '4 GB', '6 GB', '8 GB', '12 GB', '16 GB'];
export const STORAGE_OPTIONS = ['32 GB', '64 GB', '128 GB', '256 GB', '512 GB', '1 TB'];
export const PURCHASE_YEARS = [2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018];
