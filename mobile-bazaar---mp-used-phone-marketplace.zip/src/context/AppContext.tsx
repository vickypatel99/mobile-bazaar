import React, { createContext, useContext, useState, useEffect } from 'react';
import { MobileListing, UserProfile, MP_DISTRICTS } from '../types/index.ts';
import { translations, Language } from '../utils/translations.ts';

interface AppContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  user: UserProfile | null;
  setUser: (user: UserProfile | null) => void;
  selectedDistrict: string;
  setSelectedDistrict: (district: string) => void;
  activeTab: 'home' | 'buy' | 'sell' | 'my-listings' | 'favorites' | 'admin';
  setActiveTab: (tab: 'home' | 'buy' | 'sell' | 'my-listings' | 'favorites' | 'admin') => void;
  selectedListing: MobileListing | null;
  setSelectedListing: (listing: MobileListing | null) => void;
  editingListing: MobileListing | null;
  setEditingListing: (listing: MobileListing | null) => void;
  reportingListing: MobileListing | null;
  setReportingListing: (listing: MobileListing | null) => void;
  isAuthOpen: boolean;
  setIsAuthOpen: (open: boolean) => void;
  favorites: string[];
  toggleFavorite: (listingId: string) => Promise<void>;
  listings: MobileListing[];
  loadingListings: boolean;
  refreshListings: (filters?: Record<string, string>) => Promise<void>;
  t: (category: keyof typeof translations, key?: string) => any;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  toast: { msg: string; type: 'success' | 'error' | 'info' } | null;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Language>(() => {
    return (localStorage.getItem('mb_lang') as Language) || 'hi';
  });

  const [user, setUserState] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('mb_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'home' | 'buy' | 'sell' | 'my-listings' | 'favorites' | 'admin'>('home');
  const [selectedListing, setSelectedListing] = useState<MobileListing | null>(null);
  const [editingListing, setEditingListing] = useState<MobileListing | null>(null);
  const [reportingListing, setReportingListing] = useState<MobileListing | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [listings, setListings] = useState<MobileListing[]>([]);
  const [loadingListings, setLoadingListings] = useState<boolean>(true);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    localStorage.setItem('mb_lang', newLang);
    document.documentElement.lang = newLang;
  };

  const setUser = (newUser: UserProfile | null) => {
    setUserState(newUser);
    if (newUser) {
      localStorage.setItem('mb_user', JSON.stringify(newUser));
    } else {
      localStorage.removeItem('mb_user');
    }
  };

  const showToast = (msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ msg, type });
    setTimeout(() => {
      setToast(prev => (prev?.msg === msg ? null : prev));
    }, 4000);
  };

  const refreshListings = async (customFilters?: Record<string, string>) => {
    setLoadingListings(true);
    try {
      const params = new URLSearchParams();
      if (selectedDistrict && selectedDistrict !== 'all') {
        const found = MP_DISTRICTS.find(d => d.id === selectedDistrict);
        params.set('district', found ? found.en : selectedDistrict);
      }
      if (customFilters) {
        Object.entries(customFilters).forEach(([k, v]) => {
          if (v && v !== 'all') params.set(k, v);
        });
      }

      const res = await fetch(`/api/listings?${params.toString()}`);
      const data = await res.json();
      if (data.success) {
        setListings(data.listings);
      }
    } catch (err) {
      console.error('Failed to fetch listings:', err);
    } finally {
      setLoadingListings(false);
    }
  };

  // Load user favorites
  useEffect(() => {
    if (user?.phone) {
      fetch(`/api/favorites/${user.phone}`)
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            setFavorites(data.favorites || []);
          }
        })
        .catch(console.error);
    } else {
      try {
        const localFavs = localStorage.getItem('mb_guest_favs');
        if (localFavs) setFavorites(JSON.parse(localFavs));
      } catch {}
    }
  }, [user]);

  // Initial load
  useEffect(() => {
    refreshListings();
  }, [selectedDistrict]);

  const toggleFavorite = async (listingId: string) => {
    if (user?.phone) {
      try {
        const res = await fetch(`/api/listings/${listingId}/favorite`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userPhone: user.phone })
        });
        const data = await res.json();
        if (data.success) {
          setFavorites(data.favorites);
          showToast(
            data.isFavorite
              ? (lang === 'hi' ? 'पसंदीदा में जोड़ा गया' : 'Added to favorites')
              : (lang === 'hi' ? 'पसंदीदा से हटाया गया' : 'Removed from favorites'),
            'success'
          );
        }
      } catch (err) {
        console.error('Error toggling favorite:', err);
      }
    } else {
      // Guest mode favorite
      setFavorites(prev => {
        const isFav = prev.includes(listingId);
        const updated = isFav ? prev.filter(id => id !== listingId) : [...prev, listingId];
        localStorage.setItem('mb_guest_favs', JSON.stringify(updated));
        showToast(
          !isFav
            ? (lang === 'hi' ? 'पसंदीदा में जोड़ा गया' : 'Added to favorites')
            : (lang === 'hi' ? 'पसंदीदा से हटाया गया' : 'Removed from favorites'),
          'success'
        );
        return updated;
      });
    }
  };

  const t = (category: keyof typeof translations, key?: string) => {
    const cat = translations[category] as any;
    if (!cat) return '';
    if (key && cat[key]) {
      return cat[key][lang] || cat[key]['en'] || '';
    }
    return cat[lang] || cat['en'] || '';
  };

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        user,
        setUser,
        selectedDistrict,
        setSelectedDistrict,
        activeTab,
        setActiveTab,
        selectedListing,
        setSelectedListing,
        editingListing,
        setEditingListing,
        reportingListing,
        setReportingListing,
        isAuthOpen,
        setIsAuthOpen,
        favorites,
        toggleFavorite,
        listings,
        loadingListings,
        refreshListings,
        t,
        showToast,
        toast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
