import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { MobileListing } from '../types/index.ts';
import { PhoneCard } from './PhoneCard.tsx';
import { Heart, Search } from 'lucide-react';

export const FavoritesView: React.FC = () => {
  const { favorites, lang, setActiveTab, t } = useApp();
  const [favoriteListings, setFavoriteListings] = useState<MobileListing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFavorites = async () => {
      setLoading(true);
      try {
        const res = await fetch('/api/listings');
        const data = await res.json();
        if (data.success) {
          const filtered = (data.listings as MobileListing[]).filter(l => favorites.includes(l.id));
          setFavoriteListings(filtered);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchFavorites();
  }, [favorites]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="mb-6 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
          <Heart className="w-7 h-7 text-rose-500 fill-rose-500" />
          <span>{t('nav', 'favorites')}</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          {lang === 'hi'
            ? 'आपके द्वारा सहेजे गए पसंदीदा फोन। सीधे विक्रेता से संपर्क करें।'
            : 'Your saved smartphones. Contact sellers directly before they sell out.'}
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="animate-pulse bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 h-64" />
          ))}
        </div>
      ) : favoriteListings.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-12 text-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center mx-auto text-rose-400">
            <Heart className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {lang === 'hi' ? 'कोई पसंदीदा फोन नहीं मिला' : 'No saved phones yet'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {lang === 'hi'
              ? 'किसी भी फोन कार्ड पर दिल (❤️) के निशान पर क्लिक करके उसे यहाँ सेव करें।'
              : 'Tap the heart icon on any phone card to bookmark it for later.'}
          </p>
          <button
            onClick={() => setActiveTab('buy')}
            className="mt-3 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 mx-auto"
          >
            <Search className="w-4 h-4" />
            <span>{t('hero', 'exploreBtn')}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {favoriteListings.map(listing => (
            <PhoneCard key={listing.id} listing={listing} />
          ))}
        </div>
      )}

    </div>
  );
};
