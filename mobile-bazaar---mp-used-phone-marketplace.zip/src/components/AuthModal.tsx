import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { MP_DISTRICTS } from '../types/index.ts';
import { X, Smartphone, ArrowRight, CheckCircle2, ShieldCheck } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthOpen, setIsAuthOpen, setUser, showToast, lang, t } = useApp();

  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [district, setDistrict] = useState('Indore');
  const [city, setCity] = useState('');
  const [otp, setOtp] = useState('');
  const [simulatedOtp, setSimulatedOtp] = useState('1234');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    if (cleanPhone.length !== 10) {
      showToast(
        lang === 'hi' ? 'कृपया मान्य 10 अंकों का मोबाइल नंबर डालें।' : 'Please enter valid 10-digit mobile number.',
        'error'
      );
      return;
    }

    // Generate 4 digit code
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setSimulatedOtp(code);
    setOtp(code); // Pre-fill for frictionless UX
    setStep('otp');
    showToast(
      lang === 'hi'
        ? `वेरिफिकेशन कोड: ${code} (एसएमएस भेजा गया)`
        : `Verification PIN: ${code} (Sent to +91 ${cleanPhone})`,
      'info'
    );
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 4) {
      showToast(lang === 'hi' ? '4 अंकों का OTP दर्ज करें।' : 'Enter 4-digit OTP.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const cleanPhone = phone.replace(/\D/g, '').slice(-10);
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: cleanPhone,
          name: name.trim() || undefined,
          district,
          city: city.trim() || undefined,
          otp
        })
      });

      const data = await res.json();
      if (data.success) {
        setUser(data.user);
        showToast(
          lang === 'hi'
            ? `स्वागत है ${data.user.name}!`
            : `Welcome, ${data.user.name}!`,
          'success'
        );
        setIsAuthOpen(false);
      } else {
        showToast(data.message || 'Verification failed', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Login error. Please try again.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-7 space-y-5">
        
        {/* Top Close */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
              MB
            </div>
            <span className="font-bold text-slate-900 dark:text-white text-sm">
              {lang === 'hi' ? 'मोबाइल बाज़ार' : 'Mobile Bazaar'}
            </span>
          </div>
          <button
            onClick={() => setIsAuthOpen(false)}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('auth', 'title')}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {step === 'phone' ? t('auth', 'subtitle') : t('auth', 'otpHint')}
          </p>
        </div>

        {step === 'phone' ? (
          <form onSubmit={handleSendOtp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('auth', 'phoneLabel')}
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder={t('auth', 'phonePlaceholder')}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold tracking-wider text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('auth', 'nameLabel')}
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t('auth', 'namePlaceholder')}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('auth', 'districtLabel')}
                </label>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                >
                  {MP_DISTRICTS.map(d => (
                    <option key={d.id} value={d.en}>
                      {lang === 'hi' ? d.hi : d.en}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('auth', 'cityLabel')}
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Freeganj, MP Nagar"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 min-h-[44px]"
            >
              <span>{t('auth', 'sendOtp')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-300">
              <span className="font-semibold">{lang === 'hi' ? 'एसएमएस कोड भेजा गया: ' : 'SMS Code sent: '}</span>
              <span className="font-mono font-bold tracking-widest text-amber-900 dark:text-amber-200">{simulatedOtp}</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('auth', 'enterOtp')}
              </label>
              <input
                type="text"
                required
                maxLength={4}
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="4-digit PIN"
                className="w-full text-center tracking-[0.5em] text-xl font-bold py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500">
              <button
                type="button"
                onClick={() => setStep('phone')}
                className="hover:underline text-slate-600 dark:text-slate-400"
              >
                {lang === 'hi' ? '← नंबर बदलें' : '← Change Number'}
              </button>
              <button
                type="button"
                onClick={handleSendOtp}
                className="text-amber-600 font-bold hover:underline"
              >
                {t('auth', 'resendOtp')}
              </button>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 min-h-[44px]"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t('auth', 'verifyOtp')}</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
