import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { MobileListing } from '../types/index.ts';
import { PhoneCard } from './PhoneCard.tsx';
import { Smartphone, PlusCircle, CheckCircle, Trash2, Edit3, LogIn } from 'lucide-react';

export const MyListingsView: React.FC = () => {
  const { user, lang, setIsAuthOpen, setActiveTab, setEditingListing, showToast, refreshListings, t } = useApp();
  const [myListings, setMyListings] = useState<MobileListing[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMyListings = async () => {
    if (!user?.phone) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/listings?sellerPhone=${user.phone}`);
      const data = await res.json();
      if (data.success) {
        setMyListings(data.listings);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyListings();
  }, [user]);

  const handleEdit = (listing: MobileListing) => {
    setEditingListing(listing);
    setActiveTab('sell');
  };

  const handleDelete = async (listingId: string) => {
    if (!confirm(lang === 'hi' ? 'क्या आप सच में इस विज्ञापन को हटाना चाहते हैं?' : 'Are you sure you want to delete this listing?')) {
      return;
    }
    try {
      const res = await fetch(`/api/listings/${listingId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        showToast(lang === 'hi' ? 'विज्ञापन डिलीट हो गया।' : 'Listing deleted successfully.', 'success');
        setMyListings(prev => prev.filter(l => l.id !== listingId));
        refreshListings();
      }
    } catch (err) {
      console.error(err);
      showToast('Error deleting listing', 'error');
    }
  };

  const handleToggleSold = async (listing: MobileListing) => {
    const newStatus = listing.status === 'sold' ? 'active' : 'sold';
    try {
      const res = await fetch(`/api/listings/${listing.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          newStatus === 'sold'
            ? (lang === 'hi' ? 'फोन को "बिका हुआ" मार्क किया गया' : 'Marked as Sold')
            : (lang === 'hi' ? 'फोन को पुनः सक्रिय किया गया' : 'Marked as Active'),
          'success'
        );
        setMyListings(prev => prev.map(l => (l.id === listing.id ? { ...l, status: newStatus } : l)));
        refreshListings();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mx-auto">
          <LogIn className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
          {lang === 'hi' ? 'अपने विज्ञापन देखने के लिए लॉगिन करें' : 'Login to view your listings'}
        </h2>
        <p className="text-xs text-slate-500">
          {lang === 'hi'
            ? 'अपने 10 अंकों के मोबाइल नंबर से लॉगिन करें और अपने फोन के विज्ञापनों को मैनेज करें।'
            : 'Login with your 10-digit mobile number to edit, mark as sold, or remove your listings.'}
        </p>
        <button
          onClick={() => setIsAuthOpen(true)}
          className="px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md transition-all"
        >
          {t('nav', 'login')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('nav', 'myListings')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {lang === 'hi'
              ? `मोबाइल नंबर: +91 ${user.phone} · ${user.district}`
              : `Registered: +91 ${user.phone} · ${user.district}`}
          </p>
        </div>

        <button
          onClick={() => {
            setEditingListing(null);
            setActiveTab('sell');
          }}
          className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5 self-start sm:self-auto min-h-[40px]"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{lang === 'hi' ? '+ नया फोन बेचें' : '+ Post Another Phone'}</span>
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="animate-pulse bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 h-64" />
          ))}
        </div>
      ) : myListings.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
            <Smartphone className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {lang === 'hi' ? 'आपने अभी तक कोई फोन लिस्ट नहीं किया है।' : 'You have not listed any phones yet.'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {lang === 'hi'
              ? 'अपना पुराना फोन सिर्फ 2 मिनट में लिस्ट करें और मध्य प्रदेश के खरीदारों से सीधे संपर्क पाएं।'
              : 'List your used smartphone in 2 minutes and connect directly with local buyers.'}
          </p>
          <button
            onClick={() => {
              setEditingListing(null);
              setActiveTab('sell');
            }}
            className="mt-3 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            {lang === 'hi' ? 'पहला विज्ञापन डालें' : 'Post Your First Ad'}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {myListings.map(listing => (
              <div key={listing.id} className="relative flex flex-col justify-between bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
                
                {/* Visual card */}
                <PhoneCard
                  listing={listing}
                  isOwner={true}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />

                {/* Status Toggle Bar */}
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className={`font-semibold ${listing.status === 'sold' ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {listing.status === 'sold'
                      ? (lang === 'hi' ? '✓ बिका हुआ (Sold)' : '✓ Sold Out')
                      : (lang === 'hi' ? '● लाइव (Active)' : '● Active')}
                  </span>

                  <button
                    onClick={() => handleToggleSold(listing)}
                    className="font-bold text-amber-600 hover:underline"
                  >
                    {listing.status === 'sold'
                      ? (lang === 'hi' ? 'वापस सक्रिय करें' : 'Mark as Active')
                      : (lang === 'hi' ? 'बिका हुआ मार्क करें' : 'Mark as Sold')}
                  </button>
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
