import React, { useState } from 'react';
import { MobileListing } from '../types/index.ts';
import { useApp } from '../context/AppContext.tsx';
import { MapPin, Phone, MessageSquare, Heart, ShieldCheck, Image as ImageIcon } from 'lucide-react';

interface PhoneCardProps {
  listing: MobileListing;
  onEdit?: (listing: MobileListing) => void;
  onDelete?: (listingId: string) => void;
  isOwner?: boolean;
}

export const PhoneCard: React.FC<PhoneCardProps> = ({ listing, onEdit, onDelete, isOwner }) => {
  const { lang, setSelectedListing, toggleFavorite, favorites, t } = useApp();
  const [imgError, setImgError] = useState(false);

  const isFav = favorites.includes(listing.id);

  const conditionLabels: Record<string, { hi: string; en: string }> = {
    like_new: { hi: 'जैसे नया (10/10)', en: 'Like New (10/10)' },
    excellent: { hi: 'बहुत बढ़िया (9/10)', en: 'Excellent (9/10)' },
    good: { hi: 'अच्छा (7/10)', en: 'Good (7/10)' },
    fair: { hi: 'सामान्य (5/10)', en: 'Fair (5/10)' }
  };

  const condText = conditionLabels[listing.condition]
    ? conditionLabels[listing.condition][lang]
    : listing.condition;

  const formattedPrice = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(listing.price);

  const primaryPhoto = listing.photos && listing.photos.length > 0
    ? listing.photos[0]
    : '/src/assets/images/hero_smartphone_showcase_1793892269313.jpg';

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const cleanPhone = listing.sellerPhone.replace(/\D/g, '').slice(-10);
    const msg = encodeURIComponent(
      lang === 'hi'
        ? `नमस्ते ${listing.sellerName}, मैंने Mobile Bazaar पर आपका ${listing.brand} ${listing.model} (कीमत: ₹${listing.price}, जिला: ${listing.district}) देखा है। क्या यह अभी उपलब्ध है?`
        : `Hello ${listing.sellerName}, I am interested in your ${listing.brand} ${listing.model} listed on Mobile Bazaar for ₹${listing.price} from ${listing.district}. Is it still available?`
    );
    window.open(`https://wa.me/91${cleanPhone}?text=${msg}`, '_blank');
  };

  const handleCall = (e: React.MouseEvent) => {
    e.stopPropagation();
    const cleanPhone = listing.sellerPhone.replace(/\D/g, '').slice(-10);
    window.location.href = `tel:+91${cleanPhone}`;
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(listing.id);
  };

  return (
    <article
      onClick={() => setSelectedListing(listing)}
      className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col cursor-pointer"
    >
      {/* Image Container with 4:3 Aspect Ratio */}
      <div className="relative aspect-[4/3] bg-slate-100 dark:bg-slate-800 overflow-hidden">
        {!imgError ? (
          <img
            src={primaryPhoto}
            alt={`${listing.brand} ${listing.model}`}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-4 text-center">
            <ImageIcon className="w-10 h-10 mb-2 stroke-1" />
            <span className="text-xs font-medium">{listing.brand} {listing.model}</span>
          </div>
        )}

        {/* Photo count indicator */}
        {listing.photos && listing.photos.length > 1 && (
          <div className="absolute bottom-2.5 right-2.5 bg-black/70 backdrop-blur-sm text-white text-[11px] font-medium px-2 py-0.5 rounded-md flex items-center gap-1">
            <ImageIcon className="w-3 h-3" />
            <span>{listing.photos.length}</span>
          </div>
        )}

        {/* Favorite Button */}
        <button
          onClick={handleFavoriteClick}
          className="absolute top-2.5 right-2.5 w-9 h-9 rounded-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md text-slate-600 dark:text-slate-300 hover:text-rose-600 flex items-center justify-center shadow-sm transition-transform active:scale-90"
          title="Save to favorites"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isFav ? 'fill-rose-500 text-rose-500' : ''
            }`}
          />
        </button>

        {/* Sold Badge if applicable */}
        {listing.status === 'sold' && (
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center">
            <span className="bg-rose-600 text-white font-bold text-xs uppercase tracking-wider px-3 py-1 rounded-md shadow-md">
              {lang === 'hi' ? 'बिक गया (Sold)' : 'SOLD'}
            </span>
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Price & Negotiation Row */}
          <div className="flex items-baseline justify-between gap-2 mb-1.5">
            <div className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight tabular-nums">
              {formattedPrice}
            </div>
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              {listing.isNegotiable
                ? (lang === 'hi' ? 'मोल-भाव संभव' : 'Negotiable')
                : (lang === 'hi' ? 'फिक्स रेट' : 'Fixed Price')}
            </span>
          </div>

          {/* Phone Title */}
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 line-clamp-1 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
            {listing.brand} {listing.model}
          </h3>

          {/* Unboxed Metadata with Typographic Separator (Anti-slop rule §1.A) */}
          <div className="mt-1 flex items-center flex-wrap gap-1.5 text-xs text-slate-600 dark:text-slate-400">
            <span className="font-medium text-slate-700 dark:text-slate-300">{condText}</span>
            <span aria-hidden="true" className="text-slate-300 dark:text-slate-600">·</span>
            <span>{listing.ram} / {listing.storage}</span>
            <span aria-hidden="true" className="text-slate-300 dark:text-slate-600">·</span>
            <span>{listing.purchaseYear}</span>
          </div>

          {/* Location */}
          <div className="mt-2.5 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="truncate">
              {listing.city ? `${listing.city}, ` : ''}{listing.district} (MP)
            </span>
          </div>

          {/* Included Extras Icons */}
          <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-500">
            {listing.includesBill && (
              <span className="flex items-center gap-0.5 text-emerald-700 dark:text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'बिल' : 'Bill'}</span>
              </span>
            )}
            {listing.includesBox && (
              <span className="text-slate-600 dark:text-slate-400">
                + {lang === 'hi' ? 'बॉक्स' : 'Box'}
              </span>
            )}
            {listing.includesCharger && (
              <span className="text-slate-600 dark:text-slate-400">
                + {lang === 'hi' ? 'चार्जर' : 'Charger'}
              </span>
            )}
          </div>
        </div>

        {/* Direct Action Buttons: WhatsApp & Call */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-2">
          {isOwner ? (
            <div className="w-full flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit?.(listing);
                }}
                className="flex-1 py-1.5 px-3 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors min-h-[36px]"
              >
                {lang === 'hi' ? 'एडिट करें' : 'Edit'}
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete?.(listing.id);
                }}
                className="py-1.5 px-3 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors min-h-[36px]"
              >
                {lang === 'hi' ? 'हटाएं' : 'Delete'}
              </button>
            </div>
          ) : (
            <>
              {listing.whatsappEnabled && (
                <button
                  onClick={handleWhatsApp}
                  className="flex-1 min-h-[38px] flex items-center justify-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
                  title="Chat directly on WhatsApp"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              )}
              <button
                onClick={handleCall}
                className="flex-1 min-h-[38px] flex items-center justify-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 dark:bg-slate-100 dark:hover:bg-white dark:text-slate-900 text-white text-xs font-semibold rounded-xl transition-colors"
                title="Call seller directly"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'कॉल' : 'Call'}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </article>
  );
};
