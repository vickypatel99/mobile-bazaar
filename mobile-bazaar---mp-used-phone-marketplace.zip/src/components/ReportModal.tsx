import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { X, ShieldAlert, Check } from 'lucide-react';
import { translations } from '../utils/translations.ts';

export const ReportModal: React.FC = () => {
  const { reportingListing, setReportingListing, user, lang, showToast, t } = useApp();
  const [selectedReason, setSelectedReason] = useState('fake_phone');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!reportingListing) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/listings/${reportingListing.id}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reporterPhone: user?.phone || 'Guest Buyer',
          reason: selectedReason,
          details: details.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast(t('reportModal', 'success'), 'success');
        setReportingListing(null);
      } else {
        showToast('Failed to submit report', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Network error while reporting', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-5">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2 text-rose-600">
            <ShieldAlert className="w-5 h-5" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t('reportModal', 'title')}
            </h2>
          </div>
          <button
            onClick={() => setReportingListing(null)}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div>
          <div className="text-xs font-semibold text-slate-500">
            {reportingListing.brand} {reportingListing.model} · {reportingListing.district} (₹{reportingListing.price})
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('reportModal', 'subtitle')}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
              {t('reportModal', 'reasonLabel')}
            </label>
            <div className="space-y-2">
              {translations.reportModal.reasons.map(r => (
                <label
                  key={r.id}
                  className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                    selectedReason === r.id
                      ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/40 text-slate-900 dark:text-white font-medium'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <input
                    type="radio"
                    name="reason"
                    value={r.id}
                    checked={selectedReason === r.id}
                    onChange={(e) => setSelectedReason(e.target.value)}
                    className="mt-0.5 text-rose-600 focus:ring-rose-500"
                  />
                  <span>{r[lang]}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              {t('reportModal', 'detailsLabel')}
            </label>
            <textarea
              rows={2}
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder={t('reportModal', 'detailsPlaceholder')}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              {isSubmitting ? (
                <span>{lang === 'hi' ? 'भेज रहे हैं...' : 'Submitting...'}</span>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>{t('reportModal', 'submit')}</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setReportingListing(null)}
              className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-xl transition-colors"
            >
              {t('reportModal', 'cancel')}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
