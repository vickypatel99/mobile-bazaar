import React, { useState } from 'react';
import { MobileListing } from '../types/index.ts';
import { useApp } from '../context/AppContext.tsx';
import { translations } from '../utils/translations.ts';
import {
  X,
  Phone,
  MessageSquare,
  MapPin,
  Heart,
  Share2,
  ShieldAlert,
  ShieldCheck,
  Check,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Eye,
  Calendar,
  Cpu,
  HardDrive,
  Battery
} from 'lucide-react';

interface PhoneDetailModalProps {
  listing: MobileListing | null;
  onClose: () => void;
  onEdit?: (listing: MobileListing) => void;
  onDelete?: (listingId: string) => void;
}

export const PhoneDetailModal: React.FC<PhoneDetailModalProps> = ({
  listing,
  onClose,
  onEdit,
  onDelete
}) => {
  const { lang, user, toggleFavorite, favorites, setReportingListing, showToast, t } = useApp();
  const [activePhotoIdx, setActivePhotoIdx] = useState(0);

  if (!listing) return null;

  const isFav = favorites.includes(listing.id);
  const isOwner = user?.phone === listing.sellerPhone;

  const formattedPrice = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(listing.price);

  const photos = listing.photos && listing.photos.length > 0
    ? listing.photos
    : ['/src/assets/images/hero_smartphone_showcase_1793892269313.jpg'];

  const conditionLabels: Record<string, { hi: string; en: string }> = {
    like_new: { hi: 'जैसे नया (10/10)', en: 'Like New (10/10)' },
    excellent: { hi: 'बहुत बढ़िया (9/10)', en: 'Excellent (9/10)' },
    good: { hi: 'अच्छा (7/10)', en: 'Good (7/10)' },
    fair: { hi: 'सामान्य (5/10)', en: 'Fair (5/10)' }
  };

  const conditionText = conditionLabels[listing.condition]
    ? conditionLabels[listing.condition][lang]
    : listing.condition;

  const handleWhatsApp = () => {
    const cleanPhone = listing.sellerPhone.replace(/\D/g, '').slice(-10);
    const msg = encodeURIComponent(
      lang === 'hi'
        ? `नमस्ते ${listing.sellerName}, मैंने Mobile Bazaar पर आपका ${listing.brand} ${listing.model} (मूल्य: ₹${listing.price}, जिला: ${listing.district}) देखा है। क्या हम बात कर सकते हैं?`
        : `Hello ${listing.sellerName}, I am contacting you regarding your ${listing.brand} ${listing.model} (₹${listing.price}, ${listing.district}) listed on Mobile Bazaar. Is it available for purchase?`
    );
    window.open(`https://wa.me/91${cleanPhone}?text=${msg}`, '_blank');
  };

  const handleCall = () => {
    const cleanPhone = listing.sellerPhone.replace(/\D/g, '').slice(-10);
    window.location.href = `tel:+91${cleanPhone}`;
  };

  const handleShare = async () => {
    const shareData = {
      title: `${listing.brand} ${listing.model} - Mobile Bazaar`,
      text: `${listing.brand} ${listing.model} for ₹${listing.price} in ${listing.district}, MP on Mobile Bazaar`,
      url: window.location.href
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {}
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast(lang === 'hi' ? 'लिंक कॉपी हो गया!' : 'Listing link copied to clipboard!', 'success');
    }
  };

  const handleReport = () => {
    setReportingListing(listing);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      
      {/* Modal Container */}
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
              {listing.brand}
            </span>
            <span className="text-slate-300 dark:text-slate-600">·</span>
            <span className="text-xs text-slate-500 flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" />
              <span>{listing.viewsCount || 1} {lang === 'hi' ? 'व्यूज' : 'views'}</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => toggleFavorite(listing.id)}
              className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors"
              title="Save"
            >
              <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>
            <button
              onClick={handleShare}
              className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors"
              title="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {/* Photos & Main Info Split */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: Interactive Photo Gallery */}
            <div className="lg:col-span-7 space-y-3">
              <div className="relative aspect-[4/3] rounded-2xl bg-slate-950 overflow-hidden border border-slate-200/80 dark:border-slate-800">
                <img
                  src={photos[activePhotoIdx]}
                  alt={`${listing.brand} ${listing.model}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />

                {photos.length > 1 && (
                  <>
                    <button
                      onClick={() => setActivePhotoIdx((prev) => (prev > 0 ? prev - 1 : photos.length - 1))}
                      className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/90 transition-colors"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => setActivePhotoIdx((prev) => (prev < photos.length - 1 ? prev + 1 : 0))}
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/90 transition-colors"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 bg-black/70 backdrop-blur-sm text-white text-xs px-2.5 py-0.5 rounded-full font-medium">
                      {activePhotoIdx + 1} / {photos.length}
                    </div>
                  </>
                )}
              </div>

              {/* Thumbnails row */}
              {photos.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                  {photos.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActivePhotoIdx(idx)}
                      className={`relative w-16 h-12 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                        activePhotoIdx === idx
                          ? 'border-amber-600 scale-105'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={p}
                        alt="thumb"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Right: Key Specs & Price */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
              <div>
                <div className="text-3xl font-black text-slate-900 dark:text-white tabular-nums tracking-tight">
                  {formattedPrice}
                </div>
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                  {listing.isNegotiable
                    ? (lang === 'hi' ? 'मोल-भाव संभव (Negotiable)' : 'Price is Negotiable')
                    : (lang === 'hi' ? 'फिक्स रेट (Non-negotiable)' : 'Fixed Price')}
                </div>

                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-3">
                  {listing.brand} {listing.model}
                </h1>

                {/* Location */}
                <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                  <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="font-semibold">
                    {listing.city ? `${listing.city}, ` : ''}{listing.district}, Madhya Pradesh
                  </span>
                </div>

                {/* Quick Specs Grid */}
                <div className="grid grid-cols-2 gap-2 mt-4 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[11px]">{t('listingDetail', 'condition')}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{conditionText}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[11px]">{t('listingDetail', 'ram')} & {t('listingDetail', 'storage')}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{listing.ram} / {listing.storage}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[11px]">{t('listingDetail', 'year')}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{listing.purchaseYear}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[11px]">{t('listingDetail', 'battery')}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {listing.batteryHealth || (lang === 'hi' ? 'अच्छा बैकअप' : 'Good Backup')}
                    </span>
                  </div>
                </div>

                {/* Box, Bill, Charger checklist */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="text-xs font-semibold text-slate-500 mb-2">
                    {t('listingDetail', 'boxBillCharger')}
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className={`flex items-center gap-1 font-medium ${listing.includesBill ? 'text-emerald-600' : 'text-slate-400 line-through'}`}>
                      <Check className="w-3.5 h-3.5" />
                      <span>{t('listingDetail', 'bill')}</span>
                    </span>
                    <span className={`flex items-center gap-1 font-medium ${listing.includesBox ? 'text-emerald-600' : 'text-slate-400 line-through'}`}>
                      <Check className="w-3.5 h-3.5" />
                      <span>{t('listingDetail', 'box')}</span>
                    </span>
                    <span className={`flex items-center gap-1 font-medium ${listing.includesCharger ? 'text-emerald-600' : 'text-slate-400 line-through'}`}>
                      <Check className="w-3.5 h-3.5" />
                      <span>{t('listingDetail', 'charger')}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Direct Contact Seller Actions */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {t('listingDetail', 'directContact')}
                </div>

                <div className="p-3 bg-amber-50/60 dark:bg-amber-950/30 rounded-xl border border-amber-200/60 dark:border-amber-900/40 mb-3 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-slate-900 dark:text-white">
                      {listing.sellerName}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                      <span>{t('listingDetail', 'verifiedMP')} ({listing.district})</span>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                    +91 {listing.sellerPhone}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {listing.whatsappEnabled && (
                    <button
                      onClick={handleWhatsApp}
                      className="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 min-h-[44px]"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>{t('listingDetail', 'whatsappChat')}</span>
                    </button>
                  )}
                  <button
                    onClick={handleCall}
                    className="py-3 px-4 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 dark:bg-white dark:hover:bg-slate-100 dark:text-slate-900 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 min-h-[44px]"
                  >
                    <Phone className="w-4 h-4" />
                    <span>{t('listingDetail', 'callSeller')}</span>
                  </button>
                </div>

                {isOwner && (
                  <div className="flex items-center gap-2 pt-2">
                    <button
                      onClick={() => {
                        onClose();
                        onEdit?.(listing);
                      }}
                      className="flex-1 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-lg transition-colors"
                    >
                      {t('listingDetail', 'editBtn')}
                    </button>
                    <button
                      onClick={() => {
                        onClose();
                        onDelete?.(listing.id);
                      }}
                      className="py-2 px-3 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    >
                      {t('listingDetail', 'deleteBtn')}
                    </button>
                  </div>
                )}
              </div>

            </div>
          </div>

          {/* Description Section */}
          <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl p-4 sm:p-5 border border-slate-200/60 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">
              {t('listingDetail', 'description')}
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed">
              {listing.description}
            </p>
          </div>

          {/* MP Safety Guidelines */}
          <div className="bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl p-4 sm:p-5 border border-amber-200/60 dark:border-amber-900/40">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-400 mb-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>{t('listingDetail', 'safetyTitle')}</span>
            </div>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-400">
              {translations.listingDetail.safetyTips.map((tip: { en: string; hi: string }, idx: number) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-amber-600 font-bold shrink-0">✓</span>
                  <span>{tip[lang]}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Footer Report Action */}
          <div className="pt-2 flex items-center justify-between text-xs text-slate-500 border-t border-slate-100 dark:border-slate-800">
            <span>ID: {listing.id}</span>
            <button
              onClick={handleReport}
              className="flex items-center gap-1 text-rose-600 hover:text-rose-700 font-medium hover:underline"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>{t('listingDetail', 'reportBtn')}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
