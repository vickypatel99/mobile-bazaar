import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ListingReport, MobileListing, UserProfile } from '../types/index.ts';
import { ShieldCheck, ShieldAlert, Users, Smartphone, Trash2, CheckCircle, Lock, Unlock, AlertTriangle, Search } from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const { lang, user, showToast, refreshListings, t } = useApp();

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return user?.role === 'admin' || sessionStorage.getItem('mb_admin_unlocked') === 'true';
  });
  const [pinInput, setPinInput] = useState('');
  const [activeAdminTab, setActiveAdminTab] = useState<'reports' | 'listings' | 'users'>('reports');

  const [stats, setStats] = useState<{ total: number; active: number; sold: number; reported: number; users: number } | null>(null);
  const [reports, setReports] = useState<ListingReport[]>([]);
  const [adminListings, setAdminListings] = useState<MobileListing[]>([]);
  const [adminUsers, setAdminUsers] = useState<UserProfile[]>([]);
  const [searchFilter, setSearchFilter] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user?.role === 'admin') {
      setIsAuthenticated(true);
    }
  }, [user]);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [resStats, resReports, resListings, resUsers] = await Promise.all([
        fetch('/api/admin/stats').then(r => r.json()),
        fetch('/api/admin/reports').then(r => r.json()),
        fetch('/api/listings').then(r => r.json()),
        fetch('/api/admin/users').then(r => r.json())
      ]);

      if (resStats.success) setStats(resStats.stats);
      if (resReports.success) setReports(resReports.reports);
      if (resListings.success) setAdminListings(resListings.listings);
      if (resUsers.success) setAdminUsers(resUsers.users);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchAdminData();
    }
  }, [isAuthenticated]);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === '1234' || pinInput.trim() === '9826') {
      setIsAuthenticated(true);
      sessionStorage.setItem('mb_admin_unlocked', 'true');
      showToast(lang === 'hi' ? 'एडमिन पोर्टल अनलॉक हुआ' : 'Admin portal unlocked', 'success');
    } else {
      showToast(lang === 'hi' ? 'गलत पिन! (डिफ़ॉल्ट पिन: 1234)' : 'Incorrect PIN! (Default PIN: 1234)', 'error');
    }
  };

  const handleReportAction = async (reportId: string, action: 'delete_listing' | 'dismiss') => {
    try {
      const res = await fetch(`/api/admin/reports/${reportId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          action === 'delete_listing'
            ? (lang === 'hi' ? 'विज्ञापन हटा दिया गया' : 'Reported listing deleted')
            : (lang === 'hi' ? 'रिपोर्ट खारिज की गई' : 'Report dismissed'),
          'success'
        );
        fetchAdminData();
        refreshListings();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteListingDirectly = async (listingId: string) => {
    if (!confirm(lang === 'hi' ? 'क्या आप इस फोन को हटाना चाहते हैं?' : 'Delete this listing permanently?')) return;
    try {
      const res = await fetch(`/api/listings/${listingId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        showToast(lang === 'hi' ? 'लिस्टिंग हटाई गई' : 'Listing removed', 'success');
        fetchAdminData();
        refreshListings();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleUserBan = async (phone: string) => {
    try {
      const res = await fetch(`/api/admin/users/${phone}/ban`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast(
          data.user.isBanned
            ? (lang === 'hi' ? 'यूज़र ब्लॉक किया गया' : 'User banned')
            : (lang === 'hi' ? 'यूज़र अनब्लॉक किया गया' : 'User unbanned'),
          'success'
        );
        fetchAdminData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mx-auto">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            {t('admin', 'title')}
          </h2>
          <p className="text-xs text-slate-500">
            {t('admin', 'pinPrompt')}
          </p>

          <form onSubmit={handleUnlock} className="space-y-3">
            <input
              type="password"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder={t('admin', 'pinPlaceholder')}
              className="w-full text-center tracking-widest text-lg font-bold py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <button
              type="submit"
              className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <Unlock className="w-4 h-4" />
              <span>{t('admin', 'unlock')}</span>
            </button>
          </form>

          <div className="text-[11px] text-slate-400">
            {lang === 'hi' ? 'सुझाव: परीक्षण के लिए पिन 1234 का उपयोग करें।' : 'Hint: Use default PIN 1234 for review.'}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-amber-600" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {t('admin', 'title')}
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {t('admin', 'subtitle')}
          </p>
        </div>

        <button
          onClick={() => {
            setIsAuthenticated(false);
            sessionStorage.removeItem('mb_admin_unlocked');
          }}
          className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-white self-start sm:self-auto py-1 px-3 rounded-lg border border-slate-200 dark:border-slate-700"
        >
          {lang === 'hi' ? 'लॉगआउट एडमिन' : 'Lock Admin'}
        </button>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="text-xs text-slate-400 font-medium">{t('admin', 'totalListings')}</div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {stats?.total ?? 0}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="text-xs text-slate-400 font-medium">{t('admin', 'activeListings')}</div>
          <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
            {stats?.active ?? 0}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="text-xs text-slate-400 font-medium">{t('admin', 'soldListings')}</div>
          <div className="text-2xl font-bold text-slate-600 dark:text-slate-400 mt-1 tabular-nums">
            {stats?.sold ?? 0}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="text-xs text-slate-400 font-medium">{t('admin', 'reportedListings')}</div>
          <div className="text-2xl font-bold text-rose-600 mt-1 tabular-nums">
            {reports.filter(r => r.status === 'pending').length}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs col-span-2 sm:col-span-1">
          <div className="text-xs text-slate-400 font-medium">{t('admin', 'totalUsers')}</div>
          <div className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1 tabular-nums">
            {stats?.users ?? 0}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveAdminTab('reports')}
          className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-colors flex items-center gap-1.5 ${
            activeAdminTab === 'reports'
              ? 'bg-white dark:bg-slate-900 text-rose-600 border-t-2 border-t-rose-600 border-x border-slate-200 dark:border-slate-800'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>{t('admin', 'tabReports')}</span>
          {reports.filter(r => r.status === 'pending').length > 0 && (
            <span className="w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center font-bold">
              {reports.filter(r => r.status === 'pending').length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveAdminTab('listings')}
          className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-colors flex items-center gap-1.5 ${
            activeAdminTab === 'listings'
              ? 'bg-white dark:bg-slate-900 text-amber-600 border-t-2 border-t-amber-600 border-x border-slate-200 dark:border-slate-800'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>{t('admin', 'tabListings')} ({adminListings.length})</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('users')}
          className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-colors flex items-center gap-1.5 ${
            activeAdminTab === 'users'
              ? 'bg-white dark:bg-slate-900 text-amber-600 border-t-2 border-t-amber-600 border-x border-slate-200 dark:border-slate-800'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>{t('admin', 'tabUsers')} ({adminUsers.length})</span>
        </button>
      </div>

      {/* Tab 1: Reported Listings */}
      {activeAdminTab === 'reports' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
          {reports.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              {lang === 'hi' ? 'कोई सक्रिय रिपोर्ट नहीं है। पूरा एमपी बाज़ार सुरक्षित है!' : 'No reports filed. Marketplace is clean!'}
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {reports.map(report => (
                <div key={report.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {report.listingTitle}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        report.status === 'pending'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {report.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 dark:text-slate-300">
                      <span className="font-semibold text-rose-600">{report.reason}:</span> {report.details || 'No additional remarks'}
                    </div>

                    <div className="text-[11px] text-slate-400 flex items-center gap-2">
                      <span>Reporter: {report.reporterPhone}</span>
                      <span>·</span>
                      <span>Date: {new Date(report.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleReportAction(report.id, 'delete_listing')}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t('admin', 'deleteListing')}</span>
                    </button>
                    <button
                      onClick={() => handleReportAction(report.id, 'dismiss')}
                      className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-lg transition-colors"
                    >
                      {t('admin', 'dismissReport')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: All Listings Management */}
      {activeAdminTab === 'listings' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="p-3 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder={lang === 'hi' ? 'मॉडल, विक्रेता या जिले से खोजें...' : 'Search listings by model, seller, district...'}
              className="w-full sm:w-80 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Phone / Model</th>
                  <th className="py-3 px-4">Price</th>
                  <th className="py-3 px-4">MP District</th>
                  <th className="py-3 px-4">Seller</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {adminListings
                  .filter(l => 
                    l.model.toLowerCase().includes(searchFilter.toLowerCase()) ||
                    l.brand.toLowerCase().includes(searchFilter.toLowerCase()) ||
                    l.sellerName.toLowerCase().includes(searchFilter.toLowerCase()) ||
                    l.district.toLowerCase().includes(searchFilter.toLowerCase())
                  )
                  .map(l => (
                    <tr key={l.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                        {l.brand} {l.model}
                      </td>
                      <td className="py-3 px-4 font-semibold tabular-nums text-slate-900 dark:text-white">
                        ₹{l.price.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                        {l.district}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800 dark:text-slate-200">{l.sellerName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">+91 {l.sellerPhone}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`font-semibold ${l.status === 'sold' ? 'text-rose-600' : 'text-emerald-600'}`}>
                          {l.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => handleDeleteListingDirectly(l.id)}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Delete Listing"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Users Management */}
      {activeAdminTab === 'users' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">User Name</th>
                  <th className="py-3 px-4">Mobile</th>
                  <th className="py-3 px-4">District</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {adminUsers.map(u => (
                  <tr key={u.phone} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                      {u.name}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-300">
                      +91 {u.phone}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {u.district}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        u.role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {u.role.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`font-semibold ${u.isBanned ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {u.isBanned ? 'BANNED' : 'ACTIVE'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {u.role !== 'admin' && (
                        <button
                          onClick={() => handleToggleUserBan(u.phone)}
                          className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                            u.isBanned
                              ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                              : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                          }`}
                        >
                          {u.isBanned ? t('admin', 'unbanUser') : t('admin', 'banUser')}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
