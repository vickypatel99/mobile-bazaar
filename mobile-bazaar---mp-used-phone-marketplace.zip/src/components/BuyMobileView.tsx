import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { PhoneCard } from './PhoneCard.tsx';
import { MP_DISTRICTS, POPULAR_BRANDS, RAM_OPTIONS, STORAGE_OPTIONS, PhoneCondition } from '../types/index.ts';
import { Search, SlidersHorizontal, X, RotateCcw, Filter, Smartphone } from 'lucide-react';

export const BuyMobileView: React.FC = () => {
  const { listings, loadingListings, refreshListings, selectedDistrict, setSelectedDistrict, lang, t } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [selectedCondition, setSelectedCondition] = useState('all');
  const [selectedRam, setSelectedRam] = useState('all');
  const [selectedStorage, setSelectedStorage] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Sync with district
  useEffect(() => {
    applyFilters();
  }, [selectedDistrict, sortBy]);

  const applyFilters = () => {
    refreshListings({
      q: searchTerm,
      brand: selectedBrand,
      minPrice,
      maxPrice,
      condition: selectedCondition,
      ram: selectedRam,
      storage: selectedStorage,
      sort: sortBy
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    applyFilters();
  };

  const resetAllFilters = () => {
    setSearchTerm('');
    setSelectedBrand('all');
    setMinPrice('');
    setMaxPrice('');
    setSelectedCondition('all');
    setSelectedRam('all');
    setSelectedStorage('all');
    setSelectedDistrict('all');
    setSortBy('newest');
    refreshListings({
      district: 'all',
      sort: 'newest'
    });
  };

  const activeFilterCount = [
    searchTerm ? 1 : 0,
    selectedBrand !== 'all' ? 1 : 0,
    selectedDistrict !== 'all' ? 1 : 0,
    minPrice || maxPrice ? 1 : 0,
    selectedCondition !== 'all' ? 1 : 0,
    selectedRam !== 'all' ? 1 : 0,
    selectedStorage !== 'all' ? 1 : 0
  ].reduce((a, b) => a + b, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Top Search & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {lang === 'hi' ? 'पुराने स्मार्टफोन खरीदें' : 'Buy Used Smartphones'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            <span className="font-semibold text-amber-600 dark:text-amber-400 tabular-nums">{listings.length}</span> {t('filters', 'resultsCount')}
          </p>
        </div>

        {/* Search input + Mobile Filter Trigger + Sort dropdown */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          <form onSubmit={handleSearchSubmit} className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={lang === 'hi' ? 'ब्रांड या मॉडल खोजें...' : 'Search brand, model...'}
              className="w-full pl-9 pr-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </form>

          {/* Sort By Select */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            <option value="newest">{t('filters', 'newest')}</option>
            <option value="price_asc">{t('filters', 'priceAsc')}</option>
            <option value="price_desc">{t('filters', 'priceDesc')}</option>
          </select>

          {/* Mobile Filter Sheet Trigger Button */}
          <button
            onClick={() => setIsMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-1.5 px-3 py-2 bg-amber-600 text-white rounded-xl text-xs font-semibold shadow-xs"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{t('filters', 'title')}</span>
            {activeFilterCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-white text-amber-700 text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Layout: Sidebar on Desktop + Listing Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Desktop Filter Sidebar */}
        <aside className="hidden lg:block lg:col-span-1 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-sm space-y-5 sticky top-20">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="flex items-center gap-1.5 text-sm font-bold text-slate-900 dark:text-white">
              <Filter className="w-4 h-4 text-amber-600" />
              <span>{t('filters', 'title')}</span>
              {activeFilterCount > 0 && (
                <span className="text-[11px] bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 px-1.5 py-0.2 rounded-full font-bold">
                  {activeFilterCount}
                </span>
              )}
            </div>
            {activeFilterCount > 0 && (
              <button
                onClick={resetAllFilters}
                className="text-xs text-amber-600 dark:text-amber-400 font-semibold hover:underline flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t('filters', 'clearAll')}</span>
              </button>
            )}
          </div>

          {/* MP District Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('filters', 'district')}
            </label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
            >
              <option value="all">📍 {t('hero', 'allMP')} (55 Districts)</option>
              {MP_DISTRICTS.map(d => (
                <option key={d.id} value={d.id}>
                  {lang === 'hi' ? `${d.hi} (${d.en})` : `${d.en} - ${d.hi}`}
                </option>
              ))}
            </select>
          </div>

          {/* Brand Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('filters', 'brand')}
            </label>
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
            >
              <option value="all">{t('filters', 'allBrands')}</option>
              {POPULAR_BRANDS.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>

          {/* Price Range */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('filters', 'priceRange')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                placeholder={t('filters', 'minPrice')}
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              />
              <input
                type="number"
                placeholder={t('filters', 'maxPrice')}
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              />
            </div>
            {/* Quick price presets */}
            <div className="flex flex-wrap gap-1 mt-2">
              {[
                { label: '< ₹10K', min: '', max: '10000' },
                { label: '₹10K-20K', min: '10000', max: '20000' },
                { label: '₹20K-40K', min: '20000', max: '40000' },
                { label: '₹40K+', min: '40000', max: '' }
              ].map(preset => (
                <button
                  type="button"
                  key={preset.label}
                  onClick={() => {
                    setMinPrice(preset.min);
                    setMaxPrice(preset.max);
                  }}
                  className="px-2 py-0.5 text-[10px] bg-slate-100 dark:bg-slate-800 hover:bg-amber-100 hover:text-amber-800 dark:hover:bg-amber-950 rounded text-slate-600 dark:text-slate-400"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Condition Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('filters', 'condition')}
            </label>
            <select
              value={selectedCondition}
              onChange={(e) => setSelectedCondition(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
            >
              <option value="all">{lang === 'hi' ? 'सभी स्थितियां' : 'All Conditions'}</option>
              <option value="like_new">{t('conditions', 'like_new')}</option>
              <option value="excellent">{t('conditions', 'excellent')}</option>
              <option value="good">{t('conditions', 'good')}</option>
              <option value="fair">{t('conditions', 'fair')}</option>
            </select>
          </div>

          {/* RAM & Storage */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('filters', 'ram')}
              </label>
              <select
                value={selectedRam}
                onChange={(e) => setSelectedRam(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              >
                <option value="all">All</option>
                {RAM_OPTIONS.map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('filters', 'storage')}
              </label>
              <select
                value={selectedStorage}
                onChange={(e) => setSelectedStorage(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              >
                <option value="all">All</option>
                {STORAGE_OPTIONS.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={applyFilters}
            className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            {t('filters', 'apply')}
          </button>
        </aside>

        {/* Listing Cards Grid */}
        <main className="lg:col-span-3">
          {loadingListings ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="animate-pulse bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="aspect-[4/3] bg-slate-200 dark:bg-slate-800 rounded-xl" />
                  <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/3" />
                  <div className="h-5 bg-slate-200 dark:bg-slate-800 rounded w-2/3" />
                  <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                </div>
              ))}
            </div>
          ) : listings.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950 flex items-center justify-center mx-auto text-amber-600">
                <Smartphone className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('filters', 'noResults')}
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {lang === 'hi'
                  ? 'अपने फ़िल्टर बदलें या किसी अन्य जिले में तलाश करें।'
                  : 'Try adjusting your search criteria or explore nearby MP districts.'}
              </p>
              <button
                onClick={resetAllFilters}
                className="mt-2 px-4 py-2 bg-amber-600 text-white font-semibold text-xs rounded-xl hover:bg-amber-700 transition-colors"
              >
                {t('filters', 'resetFilters')}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {listings.map(listing => (
                <PhoneCard key={listing.id} listing={listing} />
              ))}
            </div>
          )}
        </main>

      </div>

      {/* Mobile Slide-Up Filter Drawer (Bottom Sheet) */}
      {isMobileFilterOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setIsMobileFilterOpen(false)}
          />
          <div className="fixed inset-x-0 bottom-0 bg-white dark:bg-slate-900 rounded-t-3xl max-h-[85vh] overflow-y-auto p-5 shadow-2xl space-y-4">
            
            <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-2" />
            
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-1.5 text-base font-bold text-slate-900 dark:text-white">
                <Filter className="w-4 h-4 text-amber-600" />
                <span>{t('filters', 'title')}</span>
              </div>
              <button
                onClick={() => setIsMobileFilterOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* MP District */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t('filters', 'district')}
              </label>
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              >
                <option value="all">📍 {t('hero', 'allMP')}</option>
                {MP_DISTRICTS.map(d => (
                  <option key={d.id} value={d.id}>{lang === 'hi' ? d.hi : d.en}</option>
                ))}
              </select>
            </div>

            {/* Brand */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t('filters', 'brand')}
              </label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              >
                <option value="all">{t('filters', 'allBrands')}</option>
                {POPULAR_BRANDS.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* Price Min/Max */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t('filters', 'priceRange')}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  placeholder={t('filters', 'minPrice')}
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
                <input
                  type="number"
                  placeholder={t('filters', 'maxPrice')}
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>
            </div>

            {/* Condition */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t('filters', 'condition')}
              </label>
              <select
                value={selectedCondition}
                onChange={(e) => setSelectedCondition(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              >
                <option value="all">All Conditions</option>
                <option value="like_new">{t('conditions', 'like_new')}</option>
                <option value="excellent">{t('conditions', 'excellent')}</option>
                <option value="good">{t('conditions', 'good')}</option>
                <option value="fair">{t('conditions', 'fair')}</option>
              </select>
            </div>

            {/* Submit & Reset Buttons */}
            <div className="flex items-center gap-2 pt-2 pb-6">
              <button
                type="button"
                onClick={() => {
                  applyFilters();
                  setIsMobileFilterOpen(false);
                }}
                className="flex-1 py-3 bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs"
              >
                {t('filters', 'apply')}
              </button>
              <button
                type="button"
                onClick={() => {
                  resetAllFilters();
                  setIsMobileFilterOpen(false);
                }}
                className="py-3 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-xl"
              >
                {t('filters', 'clearAll')}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
