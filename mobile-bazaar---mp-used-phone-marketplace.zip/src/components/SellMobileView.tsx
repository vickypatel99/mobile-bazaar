import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { MobileListing, MP_DISTRICTS, POPULAR_BRANDS, RAM_OPTIONS, STORAGE_OPTIONS, PURCHASE_YEARS, PhoneCondition } from '../types/index.ts';
import { Upload, X, Check, Image as ImageIcon, Sparkles, AlertCircle } from 'lucide-react';

interface SellMobileViewProps {
  initialListing?: MobileListing | null;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export const SellMobileView: React.FC<SellMobileViewProps> = ({ initialListing, onSuccess, onCancel }) => {
  const { user, lang, setIsAuthOpen, showToast, refreshListings, setActiveTab, t } = useApp();

  const [brand, setBrand] = useState(initialListing?.brand || 'Apple iPhone');
  const [customBrand, setCustomBrand] = useState('');
  const [model, setModel] = useState(initialListing?.model || '');
  const [ram, setRam] = useState(initialListing?.ram || '8 GB');
  const [storage, setStorage] = useState(initialListing?.storage || '128 GB');
  const [condition, setCondition] = useState<PhoneCondition>(initialListing?.condition || 'excellent');
  const [purchaseYear, setPurchaseYear] = useState<number>(initialListing?.purchaseYear || 2023);
  const [price, setPrice] = useState<string>(initialListing?.price ? String(initialListing.price) : '');
  const [isNegotiable, setIsNegotiable] = useState<boolean>(initialListing?.isNegotiable !== false);
  const [description, setDescription] = useState(initialListing?.description || '');
  const [district, setDistrict] = useState(initialListing?.district || user?.district || 'Indore');
  const [city, setCity] = useState(initialListing?.city || user?.city || '');
  
  // Accessories
  const [includesBill, setIncludesBill] = useState(initialListing?.includesBill || false);
  const [includesBox, setIncludesBox] = useState(initialListing?.includesBox || false);
  const [includesCharger, setIncludesCharger] = useState(initialListing?.includesCharger || false);
  const [batteryHealth, setBatteryHealth] = useState(initialListing?.batteryHealth || '');

  // Seller info
  const [sellerName, setSellerName] = useState(initialListing?.sellerName || user?.name || '');
  const [sellerPhone, setSellerPhone] = useState(initialListing?.sellerPhone || user?.phone || '');
  const [whatsappEnabled, setWhatsappEnabled] = useState(initialListing?.whatsappEnabled !== false);

  // Photos: up to 8
  const [photos, setPhotos] = useState<string[]>(initialListing?.photos || []);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user && !sellerName) setSellerName(user.name);
    if (user && !sellerPhone) setSellerPhone(user.phone);
    if (user && !district && user.district) setDistrict(user.district);
    if (user && !city && user.city) setCity(user.city);
  }, [user]);

  // Client-side image compression helper to keep payloads fast and responsive
  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 1200;
          const MAX_HEIGHT = 1200;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.85));
          } else {
            resolve(e.target?.result as string);
          }
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (photos.length + files.length > 8) {
      showToast(
        lang === 'hi' ? 'अधिकतम 8 फोटो ही अपलोड कर सकते हैं।' : 'You can upload maximum 8 photos.',
        'error'
      );
      return;
    }

    setIsUploading(true);
    try {
      const newPhotoPromises: Promise<string>[] = [];
      const remainingSlots = 8 - photos.length;
      const count = Math.min(files.length, remainingSlots);

      for (let i = 0; i < count; i++) {
        newPhotoPromises.push(compressImage(files[i]));
      }

      const compressedPhotos = await Promise.all(newPhotoPromises);
      setPhotos(prev => [...prev, ...compressedPhotos]);
    } catch (err) {
      console.error('Image compression error:', err);
      showToast('Error processing photos. Please try again.', 'error');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user && !sellerPhone) {
      setIsAuthOpen(true);
      return;
    }

    const cleanPhone = sellerPhone.replace(/\D/g, '').slice(-10);
    if (cleanPhone.length !== 10) {
      showToast(
        lang === 'hi' ? 'कृपया मान्य 10 अंकों का मोबाइल नंबर दर्ज करें।' : 'Please enter valid 10-digit mobile number.',
        'error'
      );
      return;
    }

    const finalBrand = brand === 'Other' ? customBrand.trim() : brand;
    if (!finalBrand) {
      showToast(lang === 'hi' ? 'कृपया ब्रांड चुनें।' : 'Please select or enter brand.', 'error');
      return;
    }

    if (!model.trim()) {
      showToast(lang === 'hi' ? 'कृपया मॉडल का नाम दर्ज करें।' : 'Please enter model name.', 'error');
      return;
    }

    const numPrice = Number(price);
    if (!numPrice || numPrice <= 0) {
      showToast(lang === 'hi' ? 'कृपया मान्य कीमत दर्ज करें।' : 'Please enter valid expected price.', 'error');
      return;
    }

    if (!description.trim()) {
      showToast(lang === 'hi' ? 'कृपया फोन का संक्षिप्त विवरण लिखें।' : 'Please provide phone description.', 'error');
      return;
    }

    if (photos.length === 0) {
      showToast(
        lang === 'hi' ? 'कम से कम 1 असली फोटो अपलोड करना जरूरी है।' : 'Please upload at least 1 photo of the phone.',
        'error'
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        brand: finalBrand,
        model: model.trim(),
        ram,
        storage,
        condition,
        purchaseYear,
        price: numPrice,
        isNegotiable,
        description: description.trim(),
        district,
        city: city.trim(),
        photos,
        sellerName: sellerName.trim() || 'MP Seller',
        sellerPhone: cleanPhone,
        whatsappEnabled,
        includesBill,
        includesBox,
        includesCharger,
        batteryHealth: batteryHealth.trim() || undefined
      };

      const url = initialListing ? `/api/listings/${initialListing.id}` : '/api/listings';
      const method = initialListing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (data.success) {
        showToast(
          initialListing
            ? (lang === 'hi' ? 'विज्ञापन सफलता पूर्वक अपडेट हुआ!' : 'Listing updated successfully!')
            : (lang === 'hi' ? 'आपका विज्ञापन लाइव हो गया है!' : 'Your phone is now live on Mobile Bazaar!'),
          'success'
        );
        await refreshListings();
        if (onSuccess) {
          onSuccess();
        } else {
          setActiveTab('buy');
        }
      } else {
        showToast(data.message || 'Failed to submit listing', 'error');
      }
    } catch (err) {
      console.error('Submit error:', err);
      showToast('Network error while saving listing', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      
      {/* Header */}
      <div className="mb-6">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-3 py-1 rounded-full mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{lang === 'hi' ? '100% मुफ्त विज्ञापन · शून्य कमीशन' : '100% Free Listing · 0% Commission'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          {initialListing ? (lang === 'hi' ? 'विज्ञापन संपादित करें' : 'Edit Phone Listing') : t('sellForm', 'heading')}
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {t('sellForm', 'subheading')}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* Section 1: Photos (Up to 8) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <ImageIcon className="w-4 h-4 text-amber-600" />
              <span>{t('sellForm', 'photosLabel')}</span>
              <span className="text-xs font-normal text-slate-500">({photos.length}/8)</span>
            </label>
            <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">
              {lang === 'hi' ? 'असली फोटो से जल्दी बिकता है' : 'Real photos sell 3x faster'}
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            {t('sellForm', 'photosHint')}
          </p>

          {/* Photo Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {photos.map((photoUrl, idx) => (
              <div key={idx} className="relative aspect-[4/3] rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 group bg-slate-100 dark:bg-slate-800">
                <img
                  src={photoUrl}
                  alt={`Upload preview ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => handleRemovePhoto(idx)}
                  className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-slate-900/80 text-white flex items-center justify-center hover:bg-rose-600 transition-colors shadow-sm"
                  title="Remove photo"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
                {idx === 0 && (
                  <span className="absolute bottom-1.5 left-1.5 bg-amber-600 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                    {lang === 'hi' ? 'मुख्य फोटो' : 'Cover'}
                  </span>
                )}
              </div>
            ))}

            {photos.length < 8 && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="aspect-[4/3] rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-amber-500 dark:hover:border-amber-500 bg-slate-50 dark:bg-slate-800/50 flex flex-col items-center justify-center p-4 text-center cursor-pointer transition-colors group"
              >
                <Upload className="w-6 h-6 text-slate-400 group-hover:text-amber-600 mb-1.5 transition-colors" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 group-hover:text-amber-600">
                  {isUploading ? (lang === 'hi' ? 'प्रोसेसिंग...' : 'Compressing...') : (lang === 'hi' ? '+ फोटो जोड़ें' : '+ Add Photo')}
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  {lang === 'hi' ? 'गैलरी या कैमरा' : 'Gallery / Camera'}
                </span>
              </button>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handlePhotoUpload}
            className="hidden"
          />
        </div>

        {/* Section 2: Mobile Details */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-5">
          <h2 className="text-base font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
            {lang === 'hi' ? '1. स्मार्टफोन की जानकारी' : '1. Smartphone Specifications'}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Brand */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'brand')}
              </label>
              <select
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {POPULAR_BRANDS.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
                <option value="Other">{lang === 'hi' ? 'अन्य ब्रांड (Other)' : 'Other Brand'}</option>
              </select>
              {brand === 'Other' && (
                <input
                  type="text"
                  placeholder="Enter brand name"
                  value={customBrand}
                  onChange={(e) => setCustomBrand(e.target.value)}
                  className="mt-2 w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm"
                />
              )}
            </div>

            {/* Model */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'model')}
              </label>
              <input
                type="text"
                required
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder={t('sellForm', 'modelPlaceholder')}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* RAM */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'ram')}
              </label>
              <select
                value={ram}
                onChange={(e) => setRam(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {RAM_OPTIONS.map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>

            {/* Storage */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'storage')}
              </label>
              <select
                value={storage}
                onChange={(e) => setStorage(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {STORAGE_OPTIONS.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Condition */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'condition')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'like_new', label: t('conditions', 'like_new'), desc: t('conditionDescriptions', 'like_new') },
                  { id: 'excellent', label: t('conditions', 'excellent'), desc: t('conditionDescriptions', 'excellent') },
                  { id: 'good', label: t('conditions', 'good'), desc: t('conditionDescriptions', 'good') },
                  { id: 'fair', label: t('conditions', 'fair'), desc: t('conditionDescriptions', 'fair') }
                ].map(item => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => setCondition(item.id as PhoneCondition)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      condition === item.id
                        ? 'border-amber-600 bg-amber-50/50 dark:bg-amber-950/40 text-slate-900 dark:text-white ring-1 ring-amber-600'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-slate-50/50 dark:bg-slate-800/30'
                    }`}
                  >
                    <div className="font-bold text-xs">{item.label}</div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Purchase Year */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'purchaseYear')}
              </label>
              <select
                value={purchaseYear}
                onChange={(e) => setPurchaseYear(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {PURCHASE_YEARS.map(y => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            {/* Expected Price */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'expectedPrice')}
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500">₹</span>
                <input
                  type="number"
                  required
                  min="500"
                  max="300000"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder={t('sellForm', 'pricePlaceholder')}
                  className="w-full pl-8 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <label className="mt-2 flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isNegotiable}
                  onChange={(e) => setIsNegotiable(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                />
                <span className="text-xs text-slate-600 dark:text-slate-400">
                  {t('sellForm', 'isNegotiable')}
                </span>
              </label>
            </div>

            {/* Description */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'description')}
              </label>
              <textarea
                required
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={t('sellForm', 'descriptionPlaceholder')}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Included Accessories */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
              {t('sellForm', 'accessoriesHeading')}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <input
                  type="checkbox"
                  checked={includesBill}
                  onChange={(e) => setIncludesBill(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600"
                />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  {t('sellForm', 'includesBill')}
                </span>
              </label>
              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <input
                  type="checkbox"
                  checked={includesBox}
                  onChange={(e) => setIncludesBox(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600"
                />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  {t('sellForm', 'includesBox')}
                </span>
              </label>
              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <input
                  type="checkbox"
                  checked={includesCharger}
                  onChange={(e) => setIncludesCharger(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600"
                />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  {t('sellForm', 'includesCharger')}
                </span>
              </label>
            </div>

            <div className="mt-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('sellForm', 'batteryHealth')}
              </label>
              <input
                type="text"
                value={batteryHealth}
                onChange={(e) => setBatteryHealth(e.target.value)}
                placeholder={t('sellForm', 'batteryPlaceholder')}
                className="w-full sm:w-1/2 px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Location in Madhya Pradesh */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
            {lang === 'hi' ? '2. मध्य प्रदेश का स्थान' : '2. Location in Madhya Pradesh'}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'district')}
              </label>
              <select
                required
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {MP_DISTRICTS.map(d => (
                  <option key={d.id} value={d.en}>
                    {lang === 'hi' ? `${d.hi} (${d.en})` : `${d.en} - ${d.hi}`}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'city')}
              </label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder={t('sellForm', 'cityPlaceholder')}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Seller Contact Info */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
            {t('sellForm', 'sellerInfoHeading')}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'sellerName')}
              </label>
              <input
                type="text"
                required
                value={sellerName}
                onChange={(e) => setSellerName(e.target.value)}
                placeholder={t('sellForm', 'sellerNamePlaceholder')}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('sellForm', 'sellerPhone')}
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">+91</span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={sellerPhone}
                  onChange={(e) => setSellerPhone(e.target.value)}
                  placeholder={t('sellForm', 'sellerPhonePlaceholder')}
                  className="w-full pl-12 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold tracking-wider text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={whatsappEnabled}
                  onChange={(e) => setWhatsappEnabled(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  {t('sellForm', 'whatsappEnabled')}
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Notice for only smartphones */}
        <div className="flex items-start gap-2.5 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 text-xs text-amber-800 dark:text-amber-300">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
          <span>{t('sellForm', 'noticeOnlySmartphones')}</span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 py-3.5 px-6 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-md shadow-amber-600/30 transition-all flex items-center justify-center gap-2 min-h-[48px]"
          >
            {isSubmitting ? (
              <span>{lang === 'hi' ? 'सेव हो रहा है...' : 'Saving Listing...'}</span>
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>{initialListing ? t('sellForm', 'updateBtn') : t('sellForm', 'submitBtn')}</span>
              </>
            )}
          </button>

          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="py-3.5 px-6 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-sm rounded-xl transition-colors min-h-[48px]"
            >
              {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
            </button>
          )}
        </div>

      </form>
    </div>
  );
};
