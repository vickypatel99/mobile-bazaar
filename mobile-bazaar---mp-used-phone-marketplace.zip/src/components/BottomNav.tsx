import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Home, Search, PlusCircle, Heart, User } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, user, setIsAuthOpen, favorites, lang } = useApp();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe">
      <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-2">
        
        {/* Home */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
            activeTab === 'home' ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">
            {lang === 'hi' ? 'होम' : 'Home'}
          </span>
        </button>

        {/* Buy / Browse */}
        <button
          onClick={() => setActiveTab('buy')}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
            activeTab === 'buy' ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Search className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">
            {lang === 'hi' ? 'खरीदें' : 'Browse'}
          </span>
        </button>

        {/* Sell Center Button */}
        <button
          onClick={() => setActiveTab('sell')}
          className="flex flex-col items-center justify-center -mt-4 min-h-[44px] group"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-amber-600/30 group-active:scale-95 transition-transform">
            <PlusCircle className="w-6 h-6" />
          </div>
          <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 mt-1">
            {lang === 'hi' ? 'बेचें' : 'Sell'}
          </span>
        </button>

        {/* Favorites */}
        <button
          onClick={() => setActiveTab('favorites')}
          className={`relative flex flex-col items-center justify-center min-h-[44px] transition-colors ${
            activeTab === 'favorites' ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <div className="relative">
            <Heart className="w-5 h-5" />
            {favorites.length > 0 && (
              <span className="absolute -top-1.5 -right-2 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                {favorites.length}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-1">
            {lang === 'hi' ? 'पसंदीदा' : 'Saved'}
          </span>
        </button>

        {/* My Ads / Profile */}
        <button
          onClick={() => {
            if (!user) {
              setIsAuthOpen(true);
            } else {
              setActiveTab('my-listings');
            }
          }}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
            activeTab === 'my-listings' ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1 truncate max-w-[50px]">
            {user ? (lang === 'hi' ? 'मेरे फोन' : 'My Ads') : (lang === 'hi' ? 'लॉगिन' : 'Login')}
          </span>
        </button>

      </div>
    </nav>
  );
};
