import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { MP_DISTRICTS } from '../types/index.ts';
import { MapPin, Globe, User, ShieldAlert, PlusCircle, Heart } from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    lang,
    setLang,
    user,
    activeTab,
    setActiveTab,
    selectedDistrict,
    setSelectedDistrict,
    setIsAuthOpen,
    favorites,
    t
  } = useApp();

  const [isDistrictPickerOpen, setIsDistrictPickerOpen] = useState(false);

  const currentDistrictObj = MP_DISTRICTS.find(d => d.id === selectedDistrict);
  const districtLabel = currentDistrictObj 
    ? (lang === 'hi' ? currentDistrictObj.hi : currentDistrictObj.en)
    : (lang === 'hi' ? 'पूरा मध्य प्रदेश' : 'All MP');

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 md:gap-8">
        
        {/* Zone 1: Single Brand Wordmark */}
        <button
          onClick={() => setActiveTab('home')}
          className="text-left flex items-center gap-2 group whitespace-nowrap shrink-0 focus-visible:outline-none"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-500 text-white flex items-center justify-center font-bold text-lg shadow-sm shadow-amber-500/20 group-hover:scale-105 transition-transform">
            MB
          </div>
          <div>
            <span className="text-lg md:text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              {lang === 'hi' ? 'मोबाइल बाज़ार' : 'Mobile Bazaar'}
            </span>
          </div>
        </button>

        {/* Zone 2: 4-5 Clean Single-Line Text Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => setActiveTab('home')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'home'
                ? 'text-amber-600 dark:text-amber-400 font-semibold border-b-2 border-amber-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t('nav', 'home')}
          </button>
          <button
            onClick={() => setActiveTab('buy')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'buy'
                ? 'text-amber-600 dark:text-amber-400 font-semibold border-b-2 border-amber-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t('nav', 'buy')}
          </button>
          <button
            onClick={() => setActiveTab('favorites')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'favorites'
                ? 'text-amber-600 dark:text-amber-400 font-semibold border-b-2 border-amber-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Heart className="w-4 h-4 text-rose-500" />
            {t('nav', 'favorites')}
            {favorites.length > 0 && (
              <span className="text-xs bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-300 font-semibold px-1.5 py-0.2 rounded-full">
                {favorites.length}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              if (!user) {
                setIsAuthOpen(true);
              } else {
                setActiveTab('my-listings');
              }
            }}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'my-listings'
                ? 'text-amber-600 dark:text-amber-400 font-semibold border-b-2 border-amber-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t('nav', 'myListings')}
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1 ${
              activeTab === 'admin'
                ? 'text-amber-600 dark:text-amber-400 font-semibold border-b-2 border-amber-600'
                : 'hover:text-slate-900 dark:hover:text-white text-slate-500'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            {t('nav', 'admin')}
          </button>
        </nav>

        {/* Zone 3: Actions & Controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* MP District Picker */}
          <div className="relative">
            <button
              onClick={() => setIsDistrictPickerOpen(!isDistrictPickerOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap min-h-[38px]"
              title={lang === 'hi' ? 'मध्य प्रदेश का जिला चुनें' : 'Select MP District'}
            >
              <MapPin className="w-3.5 h-3.5 text-amber-600" />
              <span className="max-w-[100px] sm:max-w-[130px] truncate">{districtLabel}</span>
            </button>

            {isDistrictPickerOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsDistrictPickerOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-64 max-h-80 overflow-y-auto bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 z-50 p-2 text-sm">
                  <div className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                    {lang === 'hi' ? 'मध्य प्रदेश के जिले (55)' : 'MP Districts (55)'}
                  </div>
                  <button
                    onClick={() => {
                      setSelectedDistrict('all');
                      setIsDistrictPickerOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                      selectedDistrict === 'all'
                        ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300'
                        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50'
                    }`}
                  >
                    {lang === 'hi' ? '📍 पूरा मध्य प्रदेश (All MP)' : '📍 All Madhya Pradesh'}
                  </button>
                  {MP_DISTRICTS.map(dist => (
                    <button
                      key={dist.id}
                      onClick={() => {
                        setSelectedDistrict(dist.id);
                        setIsDistrictPickerOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                        selectedDistrict === dist.id
                          ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50'
                      }`}
                    >
                      <span>{lang === 'hi' ? dist.hi : dist.en}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {lang === 'hi' ? dist.en : dist.hi}
                      </span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Language Toggle (Hindi / English) */}
          <button
            onClick={() => setLang(lang === 'hi' ? 'en' : 'hi')}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors min-h-[38px]"
            title="Toggle Hindi / English"
          >
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span className="font-semibold">{lang === 'hi' ? 'English' : 'हिंदी'}</span>
          </button>

          {/* User Profile / Login */}
          {user ? (
            <button
              onClick={() => setActiveTab('my-listings')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 min-h-[38px]"
            >
              <User className="w-3.5 h-3.5 text-amber-600" />
              <span className="max-w-[80px] truncate">{user.name.split(' ')[0]}</span>
            </button>
          ) : (
            <button
              onClick={() => setIsAuthOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 min-h-[38px]"
            >
              <User className="w-3.5 h-3.5" />
              <span>{t('nav', 'login')}</span>
            </button>
          )}

          {/* Primary Action CTA: Post Ad (Sell Mobile) */}
          <button
            onClick={() => setActiveTab('sell')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 active:bg-amber-800 rounded-xl shadow-sm shadow-amber-600/20 transition-all hover:scale-[1.02] whitespace-nowrap min-h-[38px]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{lang === 'hi' ? '+ बेचें' : '+ Sell Phone'}</span>
          </button>

        </div>
      </div>
    </header>
  );
};
