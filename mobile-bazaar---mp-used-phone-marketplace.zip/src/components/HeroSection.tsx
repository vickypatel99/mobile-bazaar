import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { POPULAR_BRANDS, MP_DISTRICTS } from '../types/index.ts';
import { Search, MapPin, PlusCircle, ShieldCheck, ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  onSearch: (searchTerm: string) => void;
  onBrandSelect: (brand: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onSearch, onBrandSelect }) => {
  const { lang, setActiveTab, selectedDistrict, setSelectedDistrict, t } = useApp();
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchInput);
  };

  const topMPDistricts = [
    { id: 'all', en: 'All MP', hi: 'पूरा MP' },
    { id: 'indore', en: 'Indore', hi: 'इंदौर' },
    { id: 'bhopal', en: 'Bhopal', hi: 'भोपाल' },
    { id: 'ujjain', en: 'Ujjain', hi: 'उज्जैन' },
    { id: 'jabalpur', en: 'Jabalpur', hi: 'जबलपुर' },
    { id: 'gwalior', en: 'Gwalior', hi: 'ग्वालियर' },
    { id: 'sagar', en: 'Sagar', hi: 'सागर' },
    { id: 'ratlam', en: 'Ratlam', hi: 'रतलाम' },
    { id: 'rewa', en: 'Rewa', hi: 'रीवा' },
  ];

  return (
    <div className="relative bg-gradient-to-b from-amber-500/10 via-slate-50 to-slate-50 dark:from-amber-950/20 dark:via-slate-950 dark:to-slate-950 border-b border-slate-200/60 dark:border-slate-800/60 pt-6 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Text & Search Block */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-4">
            
            {/* Tagline trust kicker */}
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 dark:text-amber-400">
              <ShieldCheck className="w-4 h-4" />
              <span>{t('hero', 'badge')}</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-[1.15]" style={{ textWrap: 'balance' }}>
              {t('tagline')}
            </h1>

            {/* Subtitle */}
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed">
              {t('subtagline')}
            </p>

            {/* Search Bar Form */}
            <form onSubmit={handleSearchSubmit} className="mt-2 flex flex-col sm:flex-row gap-2 max-w-xl">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  placeholder={t('hero', 'searchPlaceholder')}
                  className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-sm"
                />
              </div>

              <button
                type="submit"
                className="px-6 py-3 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-semibold text-sm rounded-xl shadow-sm shadow-amber-600/30 transition-all flex items-center justify-center gap-1.5 whitespace-nowrap min-h-[44px]"
              >
                <span>{lang === 'hi' ? 'खोजें' : 'Search'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* District Quick Pills */}
            <div className="pt-2">
              <div className="flex items-center gap-2 text-xs text-slate-500 mb-1.5 font-medium">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                <span>{lang === 'hi' ? 'लोकप्रिय जिले:' : 'Popular MP Districts:'}</span>
              </div>
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {topMPDistricts.map(dist => (
                  <button
                    key={dist.id}
                    onClick={() => {
                      setSelectedDistrict(dist.id);
                      onSearch('');
                    }}
                    className={`px-2.5 py-1 text-xs rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                      selectedDistrict === dist.id
                        ? 'bg-amber-600 text-white font-medium shadow-xs'
                        : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    {lang === 'hi' ? dist.hi : dist.en}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Showcase Image Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-lg aspect-[16/10] bg-slate-900">
              <img
                src="/src/assets/images/hero_smartphone_showcase_1793892269313.jpg"
                alt="Used Smartphones Madhya Pradesh"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-5 text-white">
                <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1">
                  {lang === 'hi' ? 'सत्यापित फोन · सीधा सौदा' : 'Direct Deal · Zero Brokerage'}
                </div>
                <div className="text-lg font-bold">
                  {lang === 'hi' ? 'अपना पुराना फोन सबसे अच्छे दाम में बेचें' : 'Sell your old phone at the best market price'}
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('sell')}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{t('hero', 'quickSellBtn')}</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('buy')}
                    className="px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white font-semibold text-xs rounded-xl transition-all"
                  >
                    {t('hero', 'exploreBtn')}
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Popular Brands Horizontal Scroller */}
        <div className="mt-8 pt-6 border-t border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
              {t('hero', 'topBrands')}
            </h2>
            <button
              onClick={() => setActiveTab('buy')}
              className="text-xs font-medium text-amber-600 dark:text-amber-400 hover:underline"
            >
              {lang === 'hi' ? 'सभी देखें →' : 'View All →'}
            </button>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            <button
              onClick={() => onBrandSelect('all')}
              className="px-3.5 py-1.5 text-xs font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-xl hover:border-amber-500 whitespace-nowrap shrink-0 transition-colors shadow-2xs"
            >
              {t('filters', 'allBrands')}
            </button>
            {POPULAR_BRANDS.map(brand => (
              <button
                key={brand}
                onClick={() => onBrandSelect(brand)}
                className="px-3.5 py-1.5 text-xs font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-xl hover:border-amber-500 hover:text-amber-600 dark:hover:text-amber-400 whitespace-nowrap shrink-0 transition-colors shadow-2xs"
              >
                {brand}
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
