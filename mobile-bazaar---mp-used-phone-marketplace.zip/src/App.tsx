import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { BottomNav } from './components/BottomNav.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { BuyMobileView } from './components/BuyMobileView.tsx';
import { SellMobileView } from './components/SellMobileView.tsx';
import { MyListingsView } from './components/MyListingsView.tsx';
import { FavoritesView } from './components/FavoritesView.tsx';
import { AdminPortal } from './components/AdminPortal.tsx';
import { PhoneCard } from './components/PhoneCard.tsx';
import { PhoneDetailModal } from './components/PhoneDetailModal.tsx';
import { ReportModal } from './components/ReportModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { MP_DISTRICTS } from './types/index.ts';
import {
  ShieldCheck,
  Smartphone,
  PhoneCall,
  MessageSquare,
  Sparkles,
  ChevronRight,
  MapPin,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

const MainContent: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    selectedListing,
    setSelectedListing,
    editingListing,
    setEditingListing,
    listings,
    loadingListings,
    refreshListings,
    selectedDistrict,
    setSelectedDistrict,
    toast,
    lang,
    t
  } = useApp();

  const handleHeroSearch = (query: string) => {
    setActiveTab('buy');
    refreshListings({ q: query });
  };

  const handleBrandSelect = (brand: string) => {
    setActiveTab('buy');
    refreshListings({ brand: brand === 'all' ? '' : brand });
  };

  const featuredListings = listings.filter(l => l.isFeatured || l.price > 20000).slice(0, 4);
  const recentListings = listings.slice(0, 6);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col pb-20 md:pb-0">
      
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-18 right-4 z-50 animate-in slide-in-from-top-2 duration-200">
          <div className={`px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-semibold ${
            toast.type === 'success'
              ? 'bg-emerald-600 text-white'
              : toast.type === 'error'
              ? 'bg-rose-600 text-white'
              : 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
          }`}>
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : (
              <AlertCircle className="w-4 h-4" />
            )}
            <span>{toast.msg}</span>
          </div>
        </div>
      )}

      {/* Top Navigation */}
      <Navbar />

      {/* Dynamic View Router */}
      <div className="flex-1">
        {activeTab === 'home' && (
          <div className="space-y-8">
            <HeroSection
              onSearch={handleHeroSearch}
              onBrandSelect={handleBrandSelect}
            />

            {/* Featured & Top Deals Section */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'खास पेशकश' : 'Featured Deals'}</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-0.5">
                    {lang === 'hi' ? 'मध्य प्रदेश के टॉप स्मार्टफोन' : 'Top Deals in Madhya Pradesh'}
                  </h2>
                </div>

                <button
                  onClick={() => setActiveTab('buy')}
                  className="text-xs font-semibold text-amber-600 hover:underline flex items-center gap-1"
                >
                  <span>{lang === 'hi' ? 'सभी देखें' : 'View All'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {loadingListings ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="animate-pulse bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 h-64" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {(featuredListings.length > 0 ? featuredListings : listings.slice(0, 4)).map(listing => (
                    <PhoneCard key={listing.id} listing={listing} />
                  ))}
                </div>
              )}
            </section>

            {/* Why Mobile Bazaar in MP / Value Prop */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
              <div className="bg-gradient-to-r from-amber-600 to-amber-700 text-white rounded-3xl p-6 sm:p-10 shadow-lg relative overflow-hidden">
                <div className="relative z-10 max-w-2xl space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-200">
                    {lang === 'hi' ? 'सीधा सौदा · कोई कमीशन नहीं' : 'Direct Deal · Zero Commission'}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                    {lang === 'hi'
                      ? 'मध्य प्रदेश के हर जिले में अपना पुराना फोन बेचें'
                      : 'Buy and Sell Used Phones in Every MP District'}
                  </h3>
                  <p className="text-xs sm:text-sm text-amber-100 leading-relaxed">
                    {lang === 'hi'
                      ? 'इंदौर, भोपाल, उज्जैन, जबलपुर, ग्वालियर, सागर, रीवा, रतलाम सहित पूरे 55 जिलों में खरीदार और विक्रेता बिना किसी मध्यस्थ या ऑनलाइन पेमेंट के सीधे बात करते हैं।'
                      : 'Covering Indore, Bhopal, Ujjain, Jabalpur, Gwalior, Sagar, Rewa, Ratlam and all 55 districts. Connect directly via WhatsApp and phone calls.'}
                  </p>
                  <div className="pt-2 flex flex-wrap gap-3">
                    <button
                      onClick={() => setActiveTab('sell')}
                      className="px-5 py-2.5 bg-white text-amber-900 font-bold text-xs rounded-xl shadow-md hover:bg-amber-50 transition-colors"
                    >
                      {lang === 'hi' ? '+ मुफ्त विज्ञापन डालें' : '+ Post Free Ad'}
                    </button>
                    <button
                      onClick={() => setActiveTab('buy')}
                      className="px-5 py-2.5 bg-amber-800/80 hover:bg-amber-800 text-white font-semibold text-xs rounded-xl transition-colors"
                    >
                      {lang === 'hi' ? 'उपलब्ध फोन देखें' : 'Explore All Phones'}
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Recent Listings */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                    {lang === 'hi' ? 'हाल ही में जोड़े गए मोबाइल' : 'Recently Added Mobiles'}
                  </h2>
                  <p className="text-xs text-slate-500">
                    {lang === 'hi' ? 'आज के नए सेकंड-हैंड स्मार्टफोन' : 'Freshly verified pre-owned phones'}
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab('buy')}
                  className="text-xs font-semibold text-amber-600 hover:underline flex items-center gap-1"
                >
                  <span>{lang === 'hi' ? 'पूरा कैटलॉग' : 'Full Catalog'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {recentListings.map(listing => (
                  <PhoneCard key={listing.id} listing={listing} />
                ))}
              </div>
            </section>

            {/* Safety Advice Checklist */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex items-center gap-2 text-amber-600">
                  <ShieldCheck className="w-6 h-6" />
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {lang === 'hi' ? 'मध्य प्रदेश के खरीदारों के लिए सुरक्षा निर्देश' : 'Safety Advice for MP Buyers & Sellers'}
                  </h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-slate-600 dark:text-slate-400">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">1. सार्वजनिक स्थान पर मिलें</span>
                    <p>फोन का लेनदेन हमेशा किसी सार्वजनिक जगह (जैसे चाय की दुकान, मुख्य बाज़ार) में मिलकर ही करें।</p>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">2. *#06# से IMEI चेक करें</span>
                    <p>फोन में डायल कर IMEI देखें और असली बिल या सिम ट्रे से नंबर मैच करें।</p>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">3. सिम लगाकर कॉल जांचें</span>
                    <p>कैमरा, माइक, स्पीकर, टच स्क्रीन और चार्जिंग को 5 मिनट चलाकर तसल्ली करें।</p>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">4. एडवांस पैसे न दें</span>
                    <p>फोन हाथ में लेने और संतुष्ट होने से पहले किसी को भी टोकन या ऑनलाइन मनी ट्रांसफर न करें।</p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}

        {activeTab === 'buy' && <BuyMobileView />}
        
        {activeTab === 'sell' && (
          <SellMobileView
            initialListing={editingListing}
            onSuccess={() => {
              setEditingListing(null);
              setActiveTab('my-listings');
            }}
            onCancel={() => {
              setEditingListing(null);
              setActiveTab('home');
            }}
          />
        )}

        {activeTab === 'my-listings' && <MyListingsView />}
        {activeTab === 'favorites' && <FavoritesView />}
        {activeTab === 'admin' && <AdminPortal />}
      </div>

      {/* Mobile Bottom Navigation Bar (Thumb ergonomic for Android/mobile screens) */}
      <BottomNav />

      {/* Modals */}
      <PhoneDetailModal
        listing={selectedListing}
        onClose={() => setSelectedListing(null)}
        onEdit={(listing) => {
          setEditingListing(listing);
          setActiveTab('sell');
        }}
        onDelete={async (id) => {
          try {
            await fetch(`/api/listings/${id}`, { method: 'DELETE' });
            setSelectedListing(null);
            refreshListings();
          } catch {}
        }}
      />

      <ReportModal />
      <AuthModal />

      {/* Footer */}
      <footer className="mt-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-600 text-white font-bold flex items-center justify-center text-xs">
                MB
              </div>
              <span className="font-bold text-slate-900 dark:text-white text-sm">
                {lang === 'hi' ? 'मोबाइल बाज़ार · मध्य प्रदेश' : 'Mobile Bazaar · Madhya Pradesh'}
              </span>
            </div>
            <p className="text-center sm:text-right">
              {lang === 'hi'
                ? 'मध्य प्रदेश के लोगों के लिए 100% सीधा मोबाइल बाज़ार। शून्य ब्रोकरेज, कोई ऑनलाइन पेमेंट नहीं।'
                : '100% Direct C2C Used Smartphone Marketplace for MP. Zero Brokerage, No Online Escrow.'}
            </p>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
            <div>
              © 2026 Mobile Bazaar. All rights reserved across all 55 MP districts.
            </div>
            <div className="flex items-center gap-4">
              <span>Indore</span>
              <span>·</span>
              <span>Bhopal</span>
              <span>·</span>
              <span>Ujjain</span>
              <span>·</span>
              <span>Jabalpur</span>
              <span>·</span>
              <span>Gwalior</span>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
